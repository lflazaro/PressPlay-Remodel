﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using PressPlay.Models;
using PressPlay.Timeline;

namespace PressPlay.Helpers
{
    public static class DragDropDiagnostics
    {
        // Add this to your project to help diagnose drag-drop issues
        public static void AttachDiagnostics(UserControl control, string controlName)
        {
            if (control == null) return;

            // Add handlers for drag-drop events
            control.AllowDrop = true;
            control.DragEnter += (s, e) => LogDragEvent($"{controlName}_DragEnter", e);
            control.DragOver += (s, e) => LogDragEvent($"{controlName}_DragOver", e);
            control.DragLeave += (s, e) => LogDragEvent($"{controlName}_DragLeave", e);
            control.Drop += (s, e) => LogDragEvent($"{controlName}_Drop", e);

            System.Diagnostics.Debug.WriteLine($"Attached diagnostics to {controlName}");
        }

        private static void LogDragEvent(string eventName, DragEventArgs e)
        {
            string dataTypes = "";

            // Check for ProjectClip data
            if (e.Data.GetDataPresent(typeof(ProjectClip)))
            {
                var clip = e.Data.GetData(typeof(ProjectClip)) as ProjectClip;
                dataTypes += $"ProjectClip: {clip?.FileName} ";
            }

            // Check for file drop data
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                dataTypes += $"FileDrop: {files?.Length} files";
            }

            // Log the event
            System.Diagnostics.Debug.WriteLine($"{eventName}: DataTypes={dataTypes}, Effects={e.Effects}");
        }

        // Call this in the Loaded event of your TimelineControl
        public static void SetupTimelineDiagnostics(TimelineControl timelineControl)
        {
            if (timelineControl == null) return;

            AttachDiagnostics(timelineControl, "TimelineControl");

            // Add event handler for ProjectClipControl to debug source of drag operation
            var clipControl = FindClipControl(timelineControl);
            if (clipControl != null)
            {
                AttachDiagnostics(clipControl, "ProjectClipsControl");
            }
        }

        private static UserControl FindClipControl(DependencyObject parent)
        {
            // Traverse visual tree to find ProjectClipsControl
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);

                if (child is CustomControls.ProjectClipsControl clipControl)
                    return clipControl;

                var result = FindClipControl(child);
                if (result != null)
                    return result;
            }

            return null;
        }
    }
}
