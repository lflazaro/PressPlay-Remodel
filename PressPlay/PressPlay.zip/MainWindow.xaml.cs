﻿using PressPlay.Models;
using PressPlay.Services;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace PressPlay
{
    public partial class MainWindow : Window
    {
        private readonly IPlaybackService _playbackService;

        public MainWindow()
        {
            InitializeComponent();

            // Set the DataContext to the ViewModel
            var vm = DataContext as MainWindowViewModel;
            if (vm != null)
            {
                // Initialize the PlaybackService with media element and current project
                _playbackService = new PlaybackService(VideoPreview, vm.CurrentProject);
                vm.PlaybackService = _playbackService;

                // Log successful initialization
                System.Diagnostics.Debug.WriteLine("PlaybackService initialized successfully");

                // Connect playback service position changes to VM
                _playbackService.PositionChanged += position =>
                {
                    // Update needle position in the project
                    if (vm.CurrentProject != null)
                    {
                        vm.CurrentProject.NeedlePositionTime = TimeCode.FromTimeSpan(position, vm.CurrentProject.FPS);
                        System.Diagnostics.Debug.WriteLine($"Updated needle position to: {position}");
                    }
                };

                // Listen for drag-drop in media area
                VideoPreview.AllowDrop = true;
                VideoPreview.Drop += VideoPreview_Drop;
                VideoPreview.DragEnter += VideoPreview_DragEnter;
                VideoPreview.DragOver += VideoPreview_DragOver;

                // Hook up window closing event
                this.Closing += MainWindow_Closing;

                // Watch for media path changes
                vm.CurrentProject.PropertyChanged += (s, e) =>
                {
                    if (e.PropertyName == nameof(Project.CurrentMediaPath))
                    {
                        string path = vm.CurrentProject.CurrentMediaPath;
                        if (!string.IsNullOrEmpty(path))
                        {
                            System.Diagnostics.Debug.WriteLine($"Loading media: {path}");
                            _playbackService.LoadMedia(path);
                        }
                    }
                };

                // Handle loaded event
                this.Loaded += MainWindow_Loaded;
            }
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("MainWindow loaded");
            var vm = DataContext as MainWindowViewModel;
            if (vm != null && !string.IsNullOrEmpty(vm.CurrentProject.CurrentMediaPath))
            {
                // If we already have a media path set, try to load it
                System.Diagnostics.Debug.WriteLine($"Initial media load: {vm.CurrentProject.CurrentMediaPath}");
                _playbackService.LoadMedia(vm.CurrentProject.CurrentMediaPath);
            }
        }

        // In MainWindow.xaml.cs where the error is occurring
        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Check for unsaved changes before closing
            var vm = DataContext as MainWindowViewModel;
            if (vm != null && vm.HasUnsavedChanges)
            {
                var result = MessageBox.Show(
                    "You have unsaved changes. Do you want to save before closing?",
                    "Save Changes",
                    MessageBoxButton.YesNoCancel,
                    MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    // Call the command instead of directly calling the method
                    if (!vm.SaveProjectToFile())
                    {
                        e.Cancel = true;
                    }
                }
                else if (result == MessageBoxResult.Cancel)
                {
                    e.Cancel = true;
                }
            }

            // Clean up playback service
            if (_playbackService != null)
            {
                _playbackService.Stop();
            }
        }

        private void VideoPreview_Drop(object sender, DragEventArgs e)
        {
            var vm = DataContext as MainWindowViewModel;
            if (vm == null) return;

            // Handle clips dragged to preview
            if (e.Data.GetDataPresent(typeof(ProjectClip)))
            {
                var clip = e.Data.GetData(typeof(ProjectClip)) as ProjectClip;
                if (clip != null)
                {
                    // Store current media path in the project
                    vm.CurrentProject.CurrentMediaPath = clip.FilePath;
                    System.Diagnostics.Debug.WriteLine($"Set current media path: {clip.FilePath}");

                    // If auto-play is enabled, start playback
                    if (vm.AutoPlayNewMedia)
                    {
                        _playbackService.Play();
                    }

                    e.Handled = true;
                }
            }
            // Handle file drops from Explorer
            else if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files != null && files.Length > 0)
                {
                    // Import the files using VM command
                    vm.ImportMediaFiles(files);
                    e.Handled = true;
                }
            }
        }

        private void VideoPreview_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(typeof(ProjectClip)) ||
                e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effects = DragDropEffects.Copy;
            }
            else
            {
                e.Effects = DragDropEffects.None;
            }
            e.Handled = true;
        }

        private void VideoPreview_DragOver(object sender, DragEventArgs e)
        {
            // Same logic as DragEnter
            if (e.Data.GetDataPresent(typeof(ProjectClip)) ||
                e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effects = DragDropEffects.Copy;
            }
            else
            {
                e.Effects = DragDropEffects.None;
            }
            e.Handled = true;
        }
    }
}