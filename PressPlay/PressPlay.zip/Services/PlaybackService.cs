﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using PressPlay.Models;

namespace PressPlay.Services
{
    public interface IPlaybackService
    {
        void Play();
        void Pause();
        void Stop();
        void Rewind();
        void FastForward();
        void Seek(TimeSpan position);
        void SeekToFrame(int frameNumber, double fps);
        void LoadMedia(string filePath);
        TimeSpan CurrentPosition { get; }
        bool IsPlaying { get; }
        event Action<TimeSpan> PositionChanged;
    }

    public class PlaybackService : IPlaybackService
    {
        private readonly MediaElement _mediaElement;
        private readonly DispatcherTimer _timer;
        private readonly Project _project;
        private bool _isPlaying = false;
        private TimeSpan _lastReportedPosition = TimeSpan.Zero;
        private readonly List<ITrackItem> _queue = new List<ITrackItem>();
        private int _queueIndex;
        private bool _isPlayingTimeline = false;
        private ITrackItem _currentPlayingItem = null;
        private TimeSpan _playbackStartTime = TimeSpan.Zero;
        private int _currentPlaybackFrame = 0;
        private bool _pendingSeek = false;
        private TimeSpan _pendingSeekTime = TimeSpan.Zero;

        public TimeSpan CurrentPosition => _mediaElement.Position;
        public bool IsPlaying => _isPlaying;

        public event Action<TimeSpan> PositionChanged;

        public PlaybackService(MediaElement mediaElement, Project project = null)
        {
            _mediaElement = mediaElement ?? throw new ArgumentNullException(nameof(mediaElement));
            _project = project;

            // Set up playback timer for position updates
            _timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(33) // ~30fps update rate
            };
            _timer.Tick += Timer_Tick;

            // Hook up media events
            _mediaElement.MediaOpened += MediaElement_MediaOpened;
            _mediaElement.MediaEnded += MediaElement_MediaEnded;
            _mediaElement.MediaFailed += MediaElement_MediaFailed;

            // Set media element properties
            _mediaElement.LoadedBehavior = MediaState.Manual;
            _mediaElement.UnloadedBehavior = MediaState.Stop;
            _mediaElement.Volume = 1.0;

            System.Diagnostics.Debug.WriteLine("PlaybackService created");
        }

        // Helper: normaliza el inicio y fin del clip (asegurándose de que start <= end)
        private (int clipStart, int clipEnd) GetNormalizedClipBounds(ITrackItem item)
        {
            int start = Math.Min(item.Start.TotalFrames, item.End.TotalFrames);
            int end = Math.Max(item.Start.TotalFrames, item.End.TotalFrames);
            return (start, end);
        }

        // Helper: duración normalizada del clip
        private int GetNormalizedDuration(ITrackItem item)
        {
            var (clipStart, clipEnd) = GetNormalizedClipBounds(item);
            return clipEnd - clipStart;
        }

        public void Play()
        {
            // Si hay elementos en la línea de tiempo, reproducir según la cola
            if (_project != null && _project.Tracks.Any() && _project.Tracks.SelectMany(t => t.Items).Any())
            {
                // Construir la cola y reiniciar el índice
                BuildQueueFromTimeline();
                if (_queue.Count > 0)
                {
                    // Seleccionar el clip que contiene el needle (o el siguiente)
                    _queueIndex = _queue.FindIndex(item =>
                        item.Position.TotalFrames <= _project.NeedlePositionTime.TotalFrames &&
                        (item.Position.TotalFrames + GetNormalizedDuration(item)) > _project.NeedlePositionTime.TotalFrames);
                    if (_queueIndex < 0)
                    {
                        // Si no se encontró, usar el primer clip cuyo inicio esté después del needle
                        _queueIndex = _queue.FindIndex(item => item.Position.TotalFrames > _project.NeedlePositionTime.TotalFrames);
                        if (_queueIndex < 0)
                        {
                            // Si tampoco, tomar el primer clip de la cola
                            _queueIndex = 0;
                        }
                    }
                    _isPlayingTimeline = true;
                    var clipToPlay = _queue[_queueIndex];
                    _currentPlayingItem = clipToPlay;

                    // Calcular la posición relativa (local frame) del needle dentro del clip
                    var (clipStart, clipEnd) = GetNormalizedClipBounds(clipToPlay);
                    int localFrame = _project.NeedlePositionTime.TotalFrames < clipToPlay.Position.TotalFrames ?
                                     clipStart :
                                     _project.NeedlePositionTime.TotalFrames - clipToPlay.Position.TotalFrames + clipStart;
                    if (localFrame < clipStart)
                        localFrame = clipStart;
                    if (localFrame >= clipEnd)
                        localFrame = clipEnd - 1;

                    PlayClipFromFrame(clipToPlay, localFrame);
                    System.Diagnostics.Debug.WriteLine($"Started timeline playback from frame {_project.NeedlePositionTime.TotalFrames} (local frame {localFrame})");
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine("No items in playback queue");
                    if (_mediaElement.Source != null)
                    {
                        PlayDirectMedia();
                    }
                }
            }
            else if (_mediaElement.Source != null)
            {
                PlayDirectMedia();
            }
            else if (_project != null && !string.IsNullOrEmpty(_project.CurrentMediaPath))
            {
                System.Diagnostics.Debug.WriteLine($"Trying to load from project path: {_project.CurrentMediaPath}");
                LoadMedia(_project.CurrentMediaPath);
                PlayDirectMedia();
            }
            else
            {
                System.Diagnostics.Debug.WriteLine("Nothing to play");
            }
        }


        private void PlayDirectMedia()
        {
            // Direct media playback
            _isPlayingTimeline = false;
            _mediaElement.Play();
            _timer.Start();
            _isPlaying = true;

            // Update project state
            if (_project != null)
            {
                _project.IsPlaying = true;
            }

            System.Diagnostics.Debug.WriteLine("Playing direct media");
        }

        private void BuildQueueFromTimeline()
        {
            _queue.Clear();
            if (_project == null)
            {
                System.Diagnostics.Debug.WriteLine("No project to build queue from");
                return;
            }

            // Obtener todos los items de video (o imagen) ordenados y luego audio
            var videoItems = _project.Tracks
                                .Where(t => t.Type == TimelineTrackType.Video)
                                .SelectMany(t => t.Items)
                                .Where(i => i.FilePath != null && File.Exists(i.FilePath))
                                .OrderBy(it => it.Position.TotalFrames)
                                .ToList();
            _queue.AddRange(videoItems);

            var audioItems = _project.Tracks
                                .Where(t => t.Type == TimelineTrackType.Audio)
                                .SelectMany(t => t.Items)
                                .Where(i => i.FilePath != null && File.Exists(i.FilePath))
                                .OrderBy(it => it.Position.TotalFrames)
                                .ToList();
            _queue.AddRange(audioItems);

            // Reiniciar índice de cola
            _queueIndex = 0;

            System.Diagnostics.Debug.WriteLine($"Built queue with {_queue.Count} items");
            int index = 0;
            foreach (var item in _queue)
            {
                var (clipStart, clipEnd) = GetNormalizedClipBounds(item);
                System.Diagnostics.Debug.WriteLine($"Queue[{index}]: {item.FileName}, Position={item.Position.TotalFrames}, Start={clipStart}, End={clipEnd}, Duration={clipEnd - clipStart}");
                index++;
            }
        }

        private ITrackItem FindClipAtFrame(int frame)
        {
            return _queue.FirstOrDefault(item =>
            {
                int clipStart = item.Position.TotalFrames;
                int clipDuration = GetNormalizedDuration(item);
                return clipStart <= frame && (clipStart + clipDuration) > frame;
            });
        }

        private ITrackItem FindNextClipAfterFrame(int frame)
        {
            return _queue.Where(item => item.Position.TotalFrames > frame)
                         .OrderBy(item => item.Position.TotalFrames)
                         .FirstOrDefault();
        }

        private void PlayClipFromFrame(ITrackItem item, int localFrame)
        {
            string filePath = null;

            // Try to get the file path from the item
            if (!string.IsNullOrEmpty(item.FilePath) && File.Exists(item.FilePath))
            {
                filePath = item.FilePath;
            }
            else if (!string.IsNullOrEmpty(item.FullPath) && File.Exists(item.FullPath))
            {
                filePath = item.FullPath;
            }

            if (!string.IsNullOrEmpty(filePath))
            {
                var (clipStart, clipEnd) = GetNormalizedClipBounds(item);
                if (localFrame < clipStart)
                    localFrame = clipStart;
                if (localFrame >= clipEnd)
                    localFrame = clipEnd - 1;

                System.Diagnostics.Debug.WriteLine($"Loading clip: {filePath}, starting at local frame {localFrame}");

                // Remember the current playing item
                _currentPlayingItem = item;

                // Calculate time position from frame
                double fps = item.Start.FPS > 0 ? item.Start.FPS : 25.0;
                TimeSpan seekTime = TimeSpan.FromSeconds(localFrame / fps);

                // Remember start time for timeline sync
                _playbackStartTime = seekTime;

                // Set the pending seek flag and time
                _pendingSeek = true;
                _pendingSeekTime = seekTime;

                // Load the media
                _mediaElement.Source = new Uri(filePath, UriKind.Absolute);
            }
            else
            {
                System.Diagnostics.Debug.WriteLine("Invalid file path or file does not exist");

                // Try the next clip
                MoveToNextClip();
            }
        }

        private void MoveToNextClip()
        {
            // Incrementar el índice para pasar al siguiente clip en la cola
            _queueIndex++;
            if (_queueIndex < _queue.Count)
            {
                var nextClip = _queue[_queueIndex];
                _currentPlayingItem = nextClip;
                var (nextStart, _) = GetNormalizedClipBounds(nextClip);
                PlayClipFromFrame(nextClip, nextStart);
                System.Diagnostics.Debug.WriteLine($"Moving to next clip at frame {nextClip.Position.TotalFrames}");
            }
            else
            {
                _isPlaying = false;
                _isPlayingTimeline = false;
                _currentPlayingItem = null;
                System.Diagnostics.Debug.WriteLine("End of timeline reached");
            }
        }

        private void MediaElement_MediaOpened(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("Media opened successfully");

            if (_pendingSeek)
            {
                // Perform the pending seek
                _mediaElement.Position = _pendingSeekTime;
                _pendingSeek = false;
                System.Diagnostics.Debug.WriteLine($"Performed pending seek to {_pendingSeekTime}");
            }

            // Start playback
            _mediaElement.Play();
            _timer.Start();
            _isPlaying = true;

            // Update project state
            if (_project != null)
            {
                _project.IsPlaying = true;
            }
        }

        private void MediaElement_MediaEnded(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("Media ended");
            _timer.Stop();

            if (_isPlayingTimeline && _currentPlayingItem != null)
            {
                MoveToNextClip();
            }
            else
            {
                // Direct playback ended
                _isPlaying = false;

                // Update project state
                if (_project != null)
                {
                    _project.IsPlaying = false;
                }
            }
        }

        public void Pause()
        {
            System.Diagnostics.Debug.WriteLine("Pause called");
            _mediaElement.Pause();
            _timer.Stop();
            _isPlaying = false;

            // If we have a project, update its state
            if (_project != null)
            {
                _project.IsPlaying = false;
            }

            // Ensure final position is reported
            ReportPosition();
        }

        public void Stop()
        {
            System.Diagnostics.Debug.WriteLine("Stop called");
            _mediaElement.Stop();
            _timer.Stop();
            _isPlaying = false;
            _isPlayingTimeline = false;
            _currentPlayingItem = null;

            // If we have a project, update its state
            if (_project != null)
            {
                _project.IsPlaying = false;
            }

            // Reset to beginning
            _mediaElement.Position = TimeSpan.Zero;
            ReportPosition();
        }

        public void Rewind()
        {
            // Different behavior for timeline vs direct playback
            if (_isPlayingTimeline && _project != null)
            {
                int currentFrame = _currentPlaybackFrame;
                int framesToMove = (int)(3 * _project.FPS);
                int newFrame = Math.Max(0, currentFrame - framesToMove);

                _project.NeedlePositionTime = new TimeCode(newFrame, _project.FPS);
                _currentPlaybackFrame = newFrame;

                var clipAtNewPos = FindClipAtFrame(newFrame);
                if (clipAtNewPos != null)
                {
                    var (clipStart, clipEnd) = GetNormalizedClipBounds(clipAtNewPos);
                    int localFrame = newFrame - clipAtNewPos.Position.TotalFrames + clipStart;
                    if (localFrame < clipStart)
                        localFrame = clipStart;

                    if (_isPlaying)
                    {
                        PlayClipFromFrame(clipAtNewPos, localFrame);
                    }
                }
                else
                {
                    if (_isPlaying)
                    {
                        _mediaElement.Pause();
                        _timer.Stop();
                    }
                }

                System.Diagnostics.Debug.WriteLine($"Timeline rewind to frame {newFrame}");
            }
            else
            {
                TimeSpan newPosition = _mediaElement.Position - TimeSpan.FromSeconds(3);
                if (newPosition < TimeSpan.Zero)
                    newPosition = TimeSpan.Zero;

                System.Diagnostics.Debug.WriteLine($"Rewind to {newPosition}");
                _mediaElement.Position = newPosition;
                ReportPosition();
            }
        }

        public void FastForward()
        {
            if (_isPlayingTimeline && _project != null)
            {
                int currentFrame = _currentPlaybackFrame;
                int framesToMove = (int)(3 * _project.FPS);
                int newFrame = currentFrame + framesToMove;

                int maxFrame = (int)_project.GetTotalDuration();
                if (newFrame > maxFrame) newFrame = maxFrame;

                _project.NeedlePositionTime = new TimeCode(newFrame, _project.FPS);
                _currentPlaybackFrame = newFrame;

                var clipAtNewPos = FindClipAtFrame(newFrame);
                if (clipAtNewPos != null)
                {
                    var (clipStart, clipEnd) = GetNormalizedClipBounds(clipAtNewPos);
                    int localFrame = newFrame - clipAtNewPos.Position.TotalFrames + clipStart;
                    if (localFrame < clipStart)
                        localFrame = clipStart;
                    if (localFrame >= clipEnd)
                        localFrame = clipEnd - 1;

                    if (_isPlaying)
                    {
                        PlayClipFromFrame(clipAtNewPos, localFrame);
                    }
                }
                else
                {
                    var nextClip = FindNextClipAfterFrame(newFrame);
                    if (nextClip != null && _isPlaying)
                    {
                        var (nextStart, _) = GetNormalizedClipBounds(nextClip);
                        PlayClipFromFrame(nextClip, nextStart);
                        _project.NeedlePositionTime = nextClip.Position;
                        _currentPlaybackFrame = nextClip.Position.TotalFrames;
                    }
                    else
                    {
                        if (_isPlaying)
                        {
                            _mediaElement.Pause();
                            _timer.Stop();
                            _isPlaying = false;
                            if (_project != null)
                            {
                                _project.IsPlaying = false;
                            }
                        }
                    }
                }

                System.Diagnostics.Debug.WriteLine($"Timeline fast forward to frame {newFrame}");
            }
            else
            {
                TimeSpan newPosition = _mediaElement.Position + TimeSpan.FromSeconds(3);
                if (_mediaElement.NaturalDuration.HasTimeSpan &&
                    newPosition > _mediaElement.NaturalDuration.TimeSpan)
                {
                    newPosition = _mediaElement.NaturalDuration.TimeSpan;
                }

                System.Diagnostics.Debug.WriteLine($"Fast forward to {newPosition}");
                _mediaElement.Position = newPosition;
                ReportPosition();
            }
        }

        public void Seek(TimeSpan position)
        {
            if (_isPlayingTimeline && _project != null)
            {
                int frame = (int)(position.TotalSeconds * _project.FPS);
                SeekToFrame(frame, _project.FPS);
            }
            else
            {
                if (position < TimeSpan.Zero)
                    position = TimeSpan.Zero;

                if (_mediaElement.NaturalDuration.HasTimeSpan &&
                    position > _mediaElement.NaturalDuration.TimeSpan)
                {
                    position = _mediaElement.NaturalDuration.TimeSpan;
                }

                System.Diagnostics.Debug.WriteLine($"Seek to {position}");
                _mediaElement.Position = position;
                ReportPosition();
            }
        }

        public void SeekToFrame(int frameNumber, double fps)
        {
            if (_isPlayingTimeline && _project != null)
            {
                _project.NeedlePositionTime = new TimeCode(frameNumber, fps);
                _currentPlaybackFrame = frameNumber;

                if (_isPlaying)
                {
                    var clipAtPosition = FindClipAtFrame(frameNumber);
                    if (clipAtPosition != null)
                    {
                        var (clipStart, clipEnd) = GetNormalizedClipBounds(clipAtPosition);
                        int localFrame = frameNumber - clipAtPosition.Position.TotalFrames + clipStart;
                        if (localFrame < clipStart)
                            localFrame = clipStart;
                        if (localFrame >= clipEnd)
                            localFrame = clipEnd - 1;

                        PlayClipFromFrame(clipAtPosition, localFrame);
                    }
                    else
                    {
                        _mediaElement.Pause();
                        _timer.Stop();
                    }
                }

                System.Diagnostics.Debug.WriteLine($"Timeline seek to frame {frameNumber}");
            }
            else
            {
                if (fps <= 0) fps = 25;
                TimeSpan position = TimeSpan.FromSeconds(frameNumber / fps);
                System.Diagnostics.Debug.WriteLine($"Seek to frame {frameNumber} ({position})");
                _mediaElement.Position = position;
                ReportPosition();
            }
        }

        public void LoadMedia(string filePath)
        {
            if (string.IsNullOrEmpty(filePath))
            {
                System.Diagnostics.Debug.WriteLine("Empty file path provided to LoadMedia");
                return;
            }

            if (!File.Exists(filePath))
            {
                System.Diagnostics.Debug.WriteLine($"File does not exist: {filePath}");
                return;
            }

            try
            {
                System.Diagnostics.Debug.WriteLine($"Loading media: {filePath}");
                _mediaElement.Source = new Uri(filePath, UriKind.Absolute);
                _isPlayingTimeline = false;

                if (_project != null)
                {
                    _project.CurrentMediaPath = filePath;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error loading media: {ex.Message}");
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            ReportPosition();
        }

        private void ReportPosition()
        {
            if (_isPlayingTimeline && _currentPlayingItem != null)
            {
                try
                {
                    TimeSpan mediaPosition = _mediaElement.Position;
                    TimeSpan elapsedSinceStart = mediaPosition - _playbackStartTime;
                    if (elapsedSinceStart < TimeSpan.Zero) elapsedSinceStart = TimeSpan.Zero;

                    double fps = _currentPlayingItem.Start.FPS > 0 ? _currentPlayingItem.Start.FPS : 25.0;
                    int localFramesElapsed = (int)(elapsedSinceStart.TotalSeconds * fps);
                    var (clipStart, clipEnd) = GetNormalizedClipBounds(_currentPlayingItem);
                    int localCurrentFrame = clipStart + localFramesElapsed;

                    if (localCurrentFrame >= clipEnd)
                    {
                        System.Diagnostics.Debug.WriteLine($"Reached end of clip's edited portion at local frame {localCurrentFrame}");
                        MoveToNextClip();
                        return;
                    }

                    int timelineFrame = _currentPlayingItem.Position.TotalFrames + localFramesElapsed;
                    _currentPlaybackFrame = timelineFrame;

                    if (_project != null && Math.Abs((_project.NeedlePositionTime.TotalFrames - timelineFrame)) >= 1)
                    {
                        _project.NeedlePositionTime = new TimeCode(timelineFrame, _project.FPS);
                        PositionChanged?.Invoke(TimeSpan.FromSeconds(timelineFrame / _project.FPS));

                        System.Diagnostics.Debug.WriteLine($"Updated timeline position to frame {timelineFrame}");
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Error reporting position: {ex.Message}");
                }
            }
            else
            {
                TimeSpan currentPosition = _mediaElement.Position;
                if (Math.Abs((currentPosition - _lastReportedPosition).TotalMilliseconds) >= 33)
                {
                    _lastReportedPosition = currentPosition;
                    PositionChanged?.Invoke(currentPosition);

                    if (_project != null && _project.FPS > 0)
                    {
                        int frames = (int)(currentPosition.TotalSeconds * _project.FPS);
                        _project.NeedlePositionTime = new TimeCode(frames, _project.FPS);
                    }
                }
            }
        }

        private void MediaElement_MediaFailed(object sender, System.Windows.ExceptionRoutedEventArgs e)
        {
            _timer.Stop();
            _isPlaying = false;

            if (_project != null)
            {
                _project.IsPlaying = false;
            }

            System.Diagnostics.Debug.WriteLine($"Media error: {e.ErrorException?.Message}");

            if (_isPlayingTimeline && _currentPlayingItem != null)
            {
                MoveToNextClip();
            }
        }
    }
}
