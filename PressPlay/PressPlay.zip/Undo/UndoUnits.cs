﻿using System.Collections.Generic;
using PressPlay.Models;  // Ensure that Project, Track, IProjectClip, ITrackItem are defined here

namespace PressPlay.Undo
{
    /// <summary>
    /// Represents an undo unit.
    /// </summary>
    public interface IUndoUnit
    {
        string Name { get; }
        void Undo();
        void Redo();
    }

    /// <summary>
    /// Aggregates multiple undo units into a single unit.
    /// </summary>
    public class MultipleUndoUnits : IUndoUnit
    {
        /// <summary>
        /// Gets the name of the undo unit.
        /// </summary>
        public string Name { get; }

        /// <summary>
        /// The list of undo units.
        /// </summary>
        public List<IUndoUnit> UndoUnits { get; } = new List<IUndoUnit>();

        /// <summary>
        /// Initializes a new instance of the <see cref="MultipleUndoUnits"/> class.
        /// </summary>
        public MultipleUndoUnits()
        {
            Name = "Multiple Operations";
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MultipleUndoUnits"/> class.
        /// </summary>
        /// <param name="name">The name of the multiple undo units.</param>
        public MultipleUndoUnits(string name)
        {
            Name = name;
        }

        /// <summary>
        /// Undoes all units in reverse order.
        /// </summary>
        public void Undo()
        {
            // Undo in reverse order
            for (int i = UndoUnits.Count - 1; i >= 0; i--)
            {
                UndoUnits[i].Undo();
            }
        }

        /// <summary>
        /// Redoes all units in original order.
        /// </summary>
        public void Redo()
        {
            // Redo in original order
            foreach (var unit in UndoUnits)
            {
                unit.Redo();
            }
        }
    }



    public class TrackRemoveUndoUnit : IUndoUnit
    {
        /// <summary>
        /// Gets the name of the undo unit.
        /// </summary>
        public string Name => "Remove Track";

        /// <summary>
        /// The project containing the track.
        /// </summary>
        private readonly Project _project;

        /// <summary>
        /// The track being removed.
        /// </summary>
        private readonly Track _track;

        /// <summary>
        /// The index of the track in the project's track collection.
        /// </summary>
        private readonly int _trackIndex;

        /// <summary>
        /// Initializes a new instance of the <see cref="TrackRemoveUndoUnit"/> class.
        /// </summary>
        /// <param name="project">The project containing the track.</param>
        /// <param name="track">The track being removed.</param>
        /// <param name="trackIndex">The index of the track in the project's track collection.</param>
        public TrackRemoveUndoUnit(Project project, Track track, int trackIndex)
        {
            _project = project ?? throw new ArgumentNullException(nameof(project));
            _track = track ?? throw new ArgumentNullException(nameof(track));
            _trackIndex = trackIndex;
        }

        /// <summary>
        /// Undoes the track removal.
        /// </summary>
        public void Undo()
        {
            if (_trackIndex >= 0 && _trackIndex <= _project.Tracks.Count)
            {
                _project.Tracks.Insert(_trackIndex, _track);
            }
            else
            {
                _project.Tracks.Add(_track);
            }
        }

        /// <summary>
        /// Redoes the track removal.
        /// </summary>
        public void Redo()
        {
            _project.Tracks.Remove(_track);
        }
    }

    /// <summary>
    /// Undo unit for adding a clip.
    /// </summary>
    public class ClipAddUndoUnit : IUndoUnit
    {
        public string Name { get; } = "Add Clip";
        public Project Project { get; set; }
        public List<ProjectClip> Clips { get; } = new List<ProjectClip>();

        public ClipAddUndoUnit() { }
        public ClipAddUndoUnit(Project project)
        {
            Project = project;
        }
        public ClipAddUndoUnit(Project project, ProjectClip clip)
        {
            Project = project;
            Clips.Add(clip);
        }

        public void Undo()
        {
            foreach (var clip in Clips)
            {
                Project.Clips.Remove(clip);
            }
        }

        public void Redo()
        {
            foreach (var clip in Clips)
            {
                Project.Clips.Add(clip);
            }
        }
    }

    /// <summary>
    /// Undo unit for removing a clip.
    /// </summary>
    public class ClipRemoveUndoUnit : IUndoUnit
    {
        public string Name { get; } = "Remove Clip";
        public Project Project { get; set; }
        public List<ProjectClip> Clips { get; } = new List<ProjectClip>();
        public List<TrackAndItemData> Items { get; } = new List<TrackAndItemData>();

        public ClipRemoveUndoUnit() { }
        public ClipRemoveUndoUnit(Project project)
        {
            Project = project;
        }
        public ClipRemoveUndoUnit(Project project, ProjectClip clip)
        {
            Project = project;
            Clips.Add(clip);
        }

        public void Undo()
        {
            foreach (var clip in Clips)
            {
                Project.Clips.Add(clip);
            }
            foreach (var item in Items)
            {
                item.Track.Items.Add(item.Item);
            }
        }

        public void Redo()
        {
            foreach (var clip in Clips)
            {
                Project.Clips.Remove(clip);
            }
            foreach (var item in Items)
            {
                item.Track.Items.Remove(item.Item);
            }
        }
    }

    /// <summary>
    /// Undo unit for adding a track.
    /// </summary>
    public class TrackAddUndoUnit : IUndoUnit
    {
        /// <summary>
        /// Gets the name of the undo unit.
        /// </summary>
        public string Name => "Add Track";

        /// <summary>
        /// The project containing the track.
        /// </summary>
        private readonly Project _project;

        /// <summary>
        /// The track being added.
        /// </summary>
        private readonly Track _track;

        /// <summary>
        /// The index of the track in the project's track collection.
        /// </summary>
        private readonly int _trackIndex;

        /// <summary>
        /// Initializes a new instance of the <see cref="TrackAddUndoUnit"/> class.
        /// </summary>
        /// <param name="project">The project containing the track.</param>
        /// <param name="track">The track being added.</param>
        /// <param name="trackIndex">The index of the track in the project's track collection.</param>
        public TrackAddUndoUnit(Project project, Track track, int trackIndex)
        {
            _project = project ?? throw new ArgumentNullException(nameof(project));
            _track = track ?? throw new ArgumentNullException(nameof(track));
            _trackIndex = trackIndex;
        }

        /// <summary>
        /// Undoes the track addition.
        /// </summary>
        public void Undo()
        {
            _project.Tracks.Remove(_track);
        }

        /// <summary>
        /// Redoes the track addition.
        /// </summary>
        public void Redo()
        {
            if (_trackIndex >= 0 && _trackIndex <= _project.Tracks.Count)
            {
                _project.Tracks.Insert(_trackIndex, _track);
            }
            else
            {
                _project.Tracks.Add(_track);
            }
        }
    }

    /// <summary>
    /// Data structure that holds a track and a track item.
    /// </summary>
    public class TrackAndItemData
    {
        public Track Track { get; set; }
        public ITrackItem Item { get; set; }

        public TrackAndItemData() { }
        public TrackAndItemData(Track track, ITrackItem item)
        {
            Track = track;
            Item = item;
        }
    }

    /// <summary>
    /// Undo unit for adding a track item.
    /// </summary>
    public class TrackItemAddUndoUnit : IUndoUnit
    {
        /// <summary>
        /// Gets the name of the undo unit.
        /// </summary>
        public string Name => "Add Track Item";

        /// <summary>
        /// The track containing the item.
        /// </summary>
        private readonly Track _track;

        /// <summary>
        /// The item being added.
        /// </summary>
        private readonly ITrackItem _item;

        /// <summary>
        /// Initializes a new instance of the <see cref="TrackItemAddUndoUnit"/> class.
        /// </summary>
        /// <param name="track">The track containing the item.</param>
        /// <param name="item">The item being added.</param>
        public TrackItemAddUndoUnit(Track track, ITrackItem item)
        {
            _track = track ?? throw new ArgumentNullException(nameof(track));
            _item = item ?? throw new ArgumentNullException(nameof(item));
        }

        /// <summary>
        /// Undoes the track item addition.
        /// </summary>
        public void Undo()
        {
            _track.Items.Remove(_item);
        }

        /// <summary>
        /// Redoes the track item addition.
        /// </summary>
        public void Redo()
        {
            _track.Items.Add(_item);
        }
    }

    /// <summary>
    /// Undo unit for removing a track item.
    /// </summary>
    public class TrackItemRemoveUndoUnit : IUndoUnit
    {
        /// <summary>
        /// Gets the name of the undo unit.
        /// </summary>
        public string Name => "Remove Track Item";

        /// <summary>
        /// The track containing the item.
        /// </summary>
        private readonly Track _track;

        /// <summary>
        /// The item being removed.
        /// </summary>
        private readonly ITrackItem _item;

        /// <summary>
        /// List of track items for batch operations
        /// </summary>
        public List<TrackAndItemData> Items { get; } = new List<TrackAndItemData>();

        /// <summary>
        /// Initializes a new instance of the <see cref="TrackItemRemoveUndoUnit"/> class.
        /// </summary>
        /// <param name="track">The track containing the item.</param>
        /// <param name="item">The item being removed.</param>
        public TrackItemRemoveUndoUnit(Track track, ITrackItem item)
        {
            _track = track ?? throw new ArgumentNullException(nameof(track));
            _item = item ?? throw new ArgumentNullException(nameof(item));
        }

        /// <summary>
        /// Default constructor for batch operations using Items property
        /// </summary>
        public TrackItemRemoveUndoUnit()
        {
            _track = null;
            _item = null;
        }

        /// <summary>
        /// Undoes the track item removal.
        /// </summary>
        public void Undo()
        {
            if (_track != null && _item != null)
            {
                _track.Items.Add(_item);
            }

            foreach (var item in Items)
            {
                item.Track.Items.Add(item.Item);
            }
        }

        /// <summary>
        /// Redoes the track item removal.
        /// </summary>
        public void Redo()
        {
            if (_track != null && _item != null)
            {
                _track.Items.Remove(_item);
            }

            foreach (var item in Items)
            {
                item.Track.Items.Remove(item.Item);
            }
        }
    }

    // Newly added types:
    /// <summary>
    /// Holds old/new positions for resizing.
    /// </summary>
    public class TrackItemResizeData
    {
        public ITrackItem Item { get; }
        public TimeCode OldPosition { get; }
        public TimeCode OldStart { get; }
        public TimeCode OldEnd { get; }
        public TimeCode NewPosition { get; set; }
        public TimeCode NewStart { get; set; }
        public TimeCode NewEnd { get; set; }

        public TrackItemResizeData(ITrackItem item, TimeCode oldPos, TimeCode oldStart, TimeCode oldEnd)
        {
            Item = item;
            OldPosition = oldPos;
            OldStart = oldStart;
            OldEnd = oldEnd;
        }
    }

    /// <summary>
    /// Undo unit that applies resize changes.
    /// </summary>
        public class TrackItemResizeUndoUnit : IUndoUnit
        {
            /// <summary>
            /// Gets the name of the undo unit.
            /// </summary>
            public string Name => "Resize/Move Track Item";

            /// <summary>
            /// The track item being resized or moved.
            /// </summary>
            private readonly ITrackItem _item;

            /// <summary>
            /// The original position of the track item.
            /// </summary>
            private readonly TimeCode _originalPosition;

            /// <summary>
            /// The original start point of the track item.
            /// </summary>
            private readonly TimeCode _originalStart;

            /// <summary>
            /// The original end point of the track item.
            /// </summary>
            private readonly TimeCode _originalEnd;

            /// <summary>
            /// The new position of the track item after the change.
            /// </summary>
            private TimeCode _newPosition;

            /// <summary>
            /// The new start point of the track item after the change.
            /// </summary>
            private TimeCode _newStart;

            /// <summary>
            /// The new end point of the track item after the change.
            /// </summary>
            private TimeCode _newEnd;

            /// <summary>
            /// Initializes a new instance of the <see cref="TrackItemResizeUndoUnit"/> class.
            /// </summary>
            /// <param name="item">The track item being resized or moved.</param>
            /// <param name="originalPosition">The original position of the track item.</param>
            /// <param name="originalStart">The original start point of the track item.</param>
            /// <param name="originalEnd">The original end point of the track item.</param>
            public TrackItemResizeUndoUnit(ITrackItem item, TimeCode originalPosition, TimeCode originalStart, TimeCode originalEnd)
            {
                _item = item ?? throw new ArgumentNullException(nameof(item));
                _originalPosition = originalPosition;
                _originalStart = originalStart;
                _originalEnd = originalEnd;

                // Store current values as the new values
                _newPosition = item.Position;
                _newStart = item.Start;
                _newEnd = item.End;
            }

            /// <summary>
            /// Undoes the resize/move operation.
            /// </summary>
            public void Undo()
            {
                // Store current values before restoring originals
                _newPosition = _item.Position;
                _newStart = _item.Start;
                _newEnd = _item.End;

                // Restore original values
                _item.Position = _originalPosition;
                _item.Start = _originalStart;
                _item.End = _originalEnd;
            }

            /// <summary>
            /// Redoes the resize/move operation.
            /// </summary>
            public void Redo()
            {
                // Restore the new values
                _item.Position = _newPosition;
                _item.Start = _newStart;
                _item.End = _newEnd;
            }
        }

    /// <summary>
    /// Undo unit that applies fade changes.
    /// </summary>
    public class TrackItemFadeUndoUnit : IUndoUnit
    {
        public string Name => "Fade Change";
        private readonly ITrackItem _item;
        private readonly int _oldIn, _oldOut;
        public int NewFadeIn { get; set; }
        public int NewFadeOut { get; set; }

        public TrackItemFadeUndoUnit(ITrackItem item, int oldFadeIn, int oldFadeOut)
        {
            _item = item;
            _oldIn = oldFadeIn;
            _oldOut = oldFadeOut;
        }

        public void Undo()
        {
            _item.FadeInFrame = _oldIn;
            _item.FadeOutFrame = _oldOut;
        }

        public void Redo()
        {
            _item.FadeInFrame = NewFadeIn;
            _item.FadeOutFrame = NewFadeOut;
        }
    }
}
