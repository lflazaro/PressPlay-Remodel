﻿using PressPlay.Models;
using System;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using static PressPlay.MainWindowViewModel;

namespace PressPlay.Timeline
{
    public partial class TimelineHeaderControl : UserControl
    {
        public Project Project
        {
            get { return (Project)GetValue(ProjectProperty); }
            set { SetValue(ProjectProperty, value); }
        }

        public static readonly DependencyProperty ProjectProperty =
            DependencyProperty.Register("Project", typeof(Project), typeof(TimelineHeaderControl),
                new PropertyMetadata(null, OnProjectChangedCallback));

        public TimelineHeaderControl()
        {
            InitializeComponent();
        }

        private static void OnProjectChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as TimelineHeaderControl;
            if (e.OldValue is Project oldProject)
            {
                oldProject.PropertyChanged -= control.Project_PropertyChanged;
            }
            if (e.NewValue is Project newProject)
            {
                newProject.PropertyChanged += control.Project_PropertyChanged;
                control.InitializeHeader();
            }
        }

        private void Project_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(Project.TimelineZoom))
            {
                InitializeHeader();
            }
        }

        private void InitializeHeader()
        {
            if (Project == null)
                return;

            headerCanvas.Children.Clear();

            // Example: set header width based on total project duration.
            // (You may replace this with your own logic.)
            double totalDurationMs = 600000; // e.g. 10 minutes in ms
            double pixelsPerMs = 0.05; // adjust as needed
            headerCanvas.Width = totalDurationMs * pixelsPerMs;

            for (double x = 0; x < headerCanvas.Width; x += 100)
            {
                // Draw a vertical line at each time marker.
                var line = new Line()
                {
                    X1 = x,
                    X2 = x,
                    Y1 = 20,
                    Y2 = headerCanvas.ActualHeight,
                    Stroke = Brushes.WhiteSmoke,
                    StrokeThickness = 0.5
                };
                headerCanvas.Children.Add(line);

                // Add a time label.
                var seconds = x / (pixelsPerMs * 1000);
                var time = TimeSpan.FromSeconds(seconds);
                var label = new TextBlock()
                {
                    Text = time.ToString(@"hh\:mm\:ss"),
                    Foreground = Brushes.WhiteSmoke
                };
                Canvas.SetLeft(label, x);
                Canvas.SetTop(label, 0);
                headerCanvas.Children.Add(label);
            }
        }
    }
}