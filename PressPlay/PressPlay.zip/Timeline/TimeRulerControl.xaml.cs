﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace PressPlay.Timeline
{
    public partial class TimeRulerControl : UserControl
    {
        // DependencyProperty for total length (in ms)
        public static readonly DependencyProperty DurationProperty =
            DependencyProperty.Register(
                nameof(Duration),
                typeof(int),
                typeof(TimeRulerControl),
                new FrameworkPropertyMetadata(
                    60000, // Default: 1 minute
                    FrameworkPropertyMetadataOptions.AffectsRender));

        /// <summary>
        /// Total timeline duration in milliseconds.
        /// </summary>
        public int Duration
        {
            get => (int)GetValue(DurationProperty);
            set => SetValue(DurationProperty, value);
        }

        // Set fixed interval for major ticks
        public static readonly DependencyProperty MajorTickIntervalProperty =
            DependencyProperty.Register(
                nameof(MajorTickInterval),
                typeof(int),
                typeof(TimeRulerControl),
                new FrameworkPropertyMetadata(
                    5000,  // Default: 5 seconds
                    FrameworkPropertyMetadataOptions.AffectsRender));

        /// <summary>
        /// The spacing (in ms) between major ticks.
        /// </summary>
        public int MajorTickInterval
        {
            get => (int)GetValue(MajorTickIntervalProperty);
            set => SetValue(MajorTickIntervalProperty, value);
        }
        
        /// <summary>
        /// Frames‑per‑second used for the time‑code labels.
        /// </summary>
        public static readonly DependencyProperty FrameRateProperty =
            DependencyProperty.Register(
                nameof(FrameRate),
                typeof(double),
                typeof(TimeRulerControl),
                new FrameworkPropertyMetadata(
                    25.0,                                 // default value
                    FrameworkPropertyMetadataOptions.AffectsRender |
                    FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public double FrameRate
        {
            get => (double)GetValue(FrameRateProperty);
            set => SetValue(FrameRateProperty, value);
        }

        public TimeRulerControl()
        {
            InitializeComponent();
            this.SizeChanged += (s, e) => InvalidateVisual();
        }

        protected override void OnRender(DrawingContext dc)
        {
            base.OnRender(dc);

            // Avoid rendering if actual dimensions are invalid
            if (ActualWidth <= 0 || ActualHeight <= 0 || Duration <= 0) return;

            double width = ActualWidth;
            double height = ActualHeight;

            // Calculate pixels per millisecond
            double pxPerMs = width / Duration;
            if (pxPerMs <= 0 || double.IsNaN(pxPerMs) || double.IsInfinity(pxPerMs)) return;

            // Validate MajorTickInterval
            int interval = MajorTickInterval > 0 ? MajorTickInterval : 1000; // Default to 1-second ticks
            if (interval <= 0 || interval > Duration) return;

            // 1) Fill background
            dc.DrawRectangle(
                new SolidColorBrush(Color.FromRgb(38, 38, 38)),
                null,
                new Rect(0, 0, width, height));

            // If there's no room to draw, bail out
            if (width <= 0 || double.IsNaN(width) || height <= 0)
                return;

            // 2) Check design mode
            bool isDesignMode = DesignerProperties.GetIsInDesignMode(this);

            // Only do minimal drawing in design mode
            if (isDesignMode)
            {
                // Draw a simple placeholder text
                var ftDesign = CreateFormattedText("Timeline Ruler (Design Mode)", Brushes.Gray);
                dc.DrawText(ftDesign, new Point(5, 5));
                return;
            }

            // 3) Draw divider line at bottom
            dc.DrawLine(
                new Pen(new SolidColorBrush(Color.FromRgb(64, 64, 64)), 1.0),
                new Point(0, height - 1),
                new Point(width, height - 1));

            // 4) Draw ticks and labels
            DrawTicksAndLabels(dc, width, height, pxPerMs, interval);

            // 5) Draw minor ticks if there's enough space
            if (interval >= 2000)
            {
                DrawMinorTicks(dc, width, height, pxPerMs, interval);
            }
        }

        private void DrawTicksAndLabels(DrawingContext dc, double width, double height, double pxPerMs, int interval)
        {
            var textColor = Brushes.LightGray;
            var tickPen = new Pen(new SolidColorBrush(Color.FromRgb(100, 100, 100)), 1.0);

            // Calculate number of major ticks to draw
            int tickCount = (int)Math.Ceiling((double)Duration / interval);

            for (int i = 0; i <= tickCount; i++)
            {
                int msPosition = i * interval;
                if (msPosition > Duration) break;

                double x = msPosition * pxPerMs;

                // Draw major tick line
                dc.DrawLine(tickPen,
                    new Point(x, height - 15),
                    new Point(x, height - 1));

                // Convert milliseconds to a formatted time code
                TimeSpan timeSpan = TimeSpan.FromMilliseconds(msPosition);
                string label;

                // Format based on duration
                if (Duration > 3600000) // > 1 hour
                {
                    label = $"{(int)timeSpan.TotalHours:D2}:{timeSpan.Minutes:D2}:{timeSpan.Seconds:D2}";
                }
                else
                {
                    label = $"{timeSpan.Minutes:D2}:{timeSpan.Seconds:D2}";
                }

                // Calculate frame number if needed
                if (FrameRate > 0)
                {
                    int frameNumber = (int)((msPosition % 1000) / (1000.0 / FrameRate));
                    label += $":{frameNumber:D2}";
                }

                // Draw the time label
                var ft = CreateFormattedText(label, textColor);
                double textX = x - (ft.Width / 2);
                double textY = 2;

                // Keep text within bounds
                if (textX < 0) textX = 0;
                if (textX + ft.Width > width) textX = width - ft.Width;

                dc.DrawText(ft, new Point(textX, textY));
            }
        }

        private void DrawMinorTicks(DrawingContext dc, double width, double height, double pxPerMs, int interval)
        {
            var minorTickPen = new Pen(new SolidColorBrush(Color.FromRgb(80, 80, 80)), 0.5);

            // Calculate minor tick interval (1/5 of major interval)
            int minorInterval = interval / 5;
            if (minorInterval < 100) minorInterval = 100; // Minimum 100ms

            // Calculate number of minor ticks
            int tickCount = (int)Math.Ceiling((double)Duration / minorInterval);

            for (int i = 0; i <= tickCount; i++)
            {
                int msPosition = i * minorInterval;
                if (msPosition > Duration) break;

                // Skip positions where major ticks exist
                if (msPosition % interval == 0) continue;

                double x = msPosition * pxPerMs;

                // Draw minor tick line (shorter than major ticks)
                dc.DrawLine(minorTickPen,
                    new Point(x, height - 8),
                    new Point(x, height - 1));
            }
        }

        /// <summary>
        /// Helper to create consistent FormattedText for the timeline.
        /// </summary>
        private FormattedText CreateFormattedText(string text, Brush brush)
        {
            return new FormattedText(
                text,
                CultureInfo.InvariantCulture,
                FlowDirection.LeftToRight,
                new Typeface("Segoe UI"),
                12,
                brush,
                VisualTreeHelper.GetDpi(this).PixelsPerDip);
        }
    }
}