﻿using CommunityToolkit.Mvvm.ComponentModel;
using System.Collections.ObjectModel;

namespace PressPlay.Timeline
{
    public partial class TrackModel : ObservableObject
    {
        [ObservableProperty]
        private string _trackName = "Unnamed Track";

        [ObservableProperty]
        private ObservableCollection<ClipModel> _clips = new ObservableCollection<ClipModel>();

        // Optional: track length, track index, etc.
    }
}