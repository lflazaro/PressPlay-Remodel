﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using PressPlay.Models;
using System.Collections.ObjectModel;

namespace PressPlay.Timeline
{
    public partial class TimelineViewModel : ObservableObject
    {
        // A collection of tracks
        [ObservableProperty]
        private ObservableCollection<TrackModel> _tracks = new ObservableCollection<TrackModel>();

        // Current playhead position (in frames or ms)
        [ObservableProperty]
        private int _playheadPosition;

        // The maximum length of the timeline in frames or ms
        [ObservableProperty]
        private int _timelineDuration = 1000;
        public Project Project { get; set; }

        /// <summary>Total project length in milliseconds.</summary>
        public int ProjectDurationMs =>
            (int)Project.Tracks
                      .SelectMany(t => t.Items)
                      .Max(it => it.End.TotalMilliseconds);

        /// <summary>Use this for the ruler’s frame labels.</summary>
        public double TimelineFrameRate => Project.FPS;
    }
}
