﻿using PressPlay.Helpers;
using PressPlay.Models;
using PressPlay.Undo;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;

namespace PressPlay.Timeline
{
    public partial class TimelineControl : UserControl
    {
        #region Fields

        // Track mouse interactions for drag and selection
        private bool _isMouseDown = false;
        private Point _mouseDownPoint;
        private ITrackItem _selectedItem = null;
        private Track _currentTrack = null;

        // Flag to prevent recursive updates
        private bool _isUpdatingNeedle = false;

        // Track for dragging operations
        private bool _isDragging = false;
        private bool _isResizingLeft = false;
        private bool _isResizingRight = false;
        private double _originalLeft = 0;
        private double _originalWidth = 0;
        private TimeCode _originalPosition;
        private TimeCode _originalStart;
        private TimeCode _originalEnd;

        // Stores the mouse position for drag operations
        private Point _lastMousePosition;

        #endregion

        #region Helper Methods

        private void UpdateTimelineFromProject()
        {
            if (Project == null)
            {
                Debug.WriteLine("UpdateTimelineFromProject: Project is null");
                return;
            }

            try
            {
                // Set DataContext for child elements that need it
                tracksItemsControl.DataContext = Project;
                Debug.WriteLine($"Set tracksItemsControl.DataContext to Project");

                // Update time ruler duration based on project content
                double maxDuration = Project.GetTotalDuration();
                if (maxDuration == 0) maxDuration = 100; // Default min duration

                // Set time ruler duration (convert from frames to ms)
                if (timeRuler != null)
                {
                    double fps = Project.FPS > 0 ? Project.FPS : 25.0; // Ensure fps isn't zero
                    double ms = (maxDuration / fps) * 1000;
                    timeRuler.Duration = (int)Math.Max(30000, ms + 10000); // Add padding
                    timeRuler.FrameRate = fps;

                    // Adjust tick intervals based on zoom
                    timeRuler.MajorTickInterval = Project.TimelineZoom <= 2 ? 5000 : // 5s
                                                  Project.TimelineZoom <= 4 ? 2000 : // 2s
                                                  1000; // 1s

                    // Ensure the time ruler is visible
                    timeRuler.Visibility = Visibility.Visible;
                }

                // Update needle position if valid
                if (needle != null && Project.NeedlePositionTime != null)
                {
                    UpdateNeedlePosition();
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error in UpdateTimelineFromProject: {ex.Message}");
            }
        }

        private void UpdateNeedlePosition()
        {
            if (Project == null || needle == null)
                return;

            _isUpdatingNeedle = true;
            try
            {
                double zoomFactor = Constants.TimelineZooms.TryGetValue(Project.TimelineZoom, out var z) ? z : 1.0;
                double pixelPosition = Project.NeedlePositionTime.TotalFrames * Constants.TimelinePixelsInSeparator / zoomFactor;

                Debug.WriteLine($"Setting needle position to: {pixelPosition}px (frame {Project.NeedlePositionTime.TotalFrames})");
                needle.Margin = new Thickness(pixelPosition, 0, 0, 0);
                Canvas.SetLeft(needle, pixelPosition);
                BringNeedleIntoView();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error updating needle position: {ex.Message}");
            }
            finally
            {
                _isUpdatingNeedle = false;
            }
        }

        private void UpdateNeedlePositionFromPixels(double xPosition)
        {
            if (Project == null)
                return;

            _isUpdatingNeedle = true;
            try
            {
                double zoomFactor = Constants.TimelineZooms.TryGetValue(Project.TimelineZoom, out var z) ? z : 1.0;
                int frame = (int)(xPosition * zoomFactor / Constants.TimelinePixelsInSeparator);

                Project.NeedlePositionTime = new TimeCode(frame, Project.FPS);
                Project.RaiseNeedlePositionTimeChanged(Project.NeedlePositionTime);

                Canvas.SetLeft(needle, xPosition);
                BringNeedleIntoView();

                Debug.WriteLine($"Updated needle position from pixels: {xPosition}px -> frame {frame}");
            }
            finally
            {
                _isUpdatingNeedle = false;
            }
        }

        private void BringNeedleIntoView()
        {
            if (needle == null || tracksScrollViewer == null)
                return;

            double needlePos = Canvas.GetLeft(needle);
            if (double.IsNaN(needlePos)) needlePos = 0;

            double viewport = tracksScrollViewer.ViewportWidth;
            double offset = tracksScrollViewer.HorizontalOffset;

            if (needlePos < offset || needlePos > offset + viewport)
                tracksScrollViewer.ScrollToHorizontalOffset(needlePos - viewport / 2);
        }

        private bool IsClickOnTrackItem(MouseButtonEventArgs e)
        {
            var element = e.OriginalSource as DependencyObject;
            while (element != null)
            {
                if (element is TrackItemControl) return true;
                element = VisualTreeHelper.GetParent(element);
            }
            return false;
        }

        private Track FindParentTrack(ITrackItem item)
        {
            return Project.Tracks.FirstOrDefault(t => t.Items.Contains(item));
        }

        private void ClearAllSelections()
        {
            if (Project == null) return;
            foreach (var track in Project.Tracks)
                foreach (var item in track.Items)
                    item.IsSelected = false;
            _selectedItem = null;
        }

        private void DeleteSelectedItems()
        {
            if (Project == null) return;

            // Find all selected items
            var selectedItems = new List<ITrackItem>();
            foreach (var track in Project.Tracks)
            {
                foreach (var item in track.Items)
                {
                    if (item.IsSelected)
                    {
                        selectedItems.Add(item);
                    }
                }
            }

            if (selectedItems.Count > 0)
            {
                Debug.WriteLine($"Deleting {selectedItems.Count} selected items");
                Project.DeleteSelectedItems();
            }
            else
            {
                Debug.WriteLine("No items selected to delete");
            }
        }

        #endregion

        #region Undo Registration Methods

        private void RegisterTrackItemAdd(Track track, ITrackItem item)
        {
            var undo = new TrackItemAddUndoUnit(track, item);
            UndoEngine.Instance.AddUndoUnit(undo);
        }

        private void RegisterTrackItemRemove(Track track, ITrackItem item)
        {
            var undo = new TrackItemRemoveUndoUnit(track, item);
            UndoEngine.Instance.AddUndoUnit(undo);
        }

        private void RegisterTrackItemChange()
        {
            if (_selectedItem == null) return;
            var undo = new TrackItemResizeUndoUnit(
                _selectedItem, _originalPosition, _originalStart, _originalEnd);
            UndoEngine.Instance.AddUndoUnit(undo);
        }

        private void RegisterTrackAdd(Track track)
        {
            var undo = new TrackAddUndoUnit(Project, track, Project.Tracks.Count - 1);
            UndoEngine.Instance.AddUndoUnit(undo);
        }

        #endregion

        #region Dependency Properties

        public static readonly DependencyProperty ProjectProperty =
            DependencyProperty.Register(
                nameof(Project),
                typeof(Project),
                typeof(TimelineControl),
                new PropertyMetadata(null, OnProjectChangedCallback));

        public Project Project
        {
            get => (Project)GetValue(ProjectProperty);
            set => SetValue(ProjectProperty, value);
        }

        #endregion

        #region Constructor

        public TimelineControl()
        {
            InitializeComponent();

            Resources.Add("FrameToPositionConverter", new Converters.FrameToPositionConverter());
            Resources.Add("FrameToWidthConverter", new Converters.FrameToWidthConverter());

            Loaded += TimelineControl_Loaded;

            // Add mouse event handlers for the entire control
            this.PreviewMouseMove += TimelineControl_PreviewMouseMove;
            this.PreviewMouseLeftButtonUp += TimelineControl_PreviewMouseLeftButtonUp;
        }

        #endregion

        #region Event Handlers

        protected override void OnInitialized(EventArgs e)
        {
            base.OnInitialized(e);
            if (Project == null)
                Debug.WriteLine("TimelineControl initialized with null Project");
        }

        private void TimelineControl_Loaded(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("TimelineControl loaded");

            if (timeRuler != null && Project != null)
            {
                timeRuler.Duration = 30000;
                timeRuler.FrameRate = Project.FPS;
            }

            if (tracksRoot != null && Project != null)
            {
                tracksRoot.Tag = Project.TimelineZoom;
                Project.PropertyChanged += (s, args) =>
                {
                    if (args.PropertyName == nameof(Project.TimelineZoom))
                        tracksRoot.Tag = Project.TimelineZoom;
                };
            }

            if (tracksItemsControl != null && Project != null)
            {
                RefreshTrackDisplay();
            }

            if (Project != null)
            {
                Project.PropertyChanged += Project_PropertyChanged;
                Project.NeedlePositionTimeChanged += Project_NeedlePositionTimeChanged;
                UpdateTimelineFromProject();
            }

            WireUpTrackItemEvents();

            // Set up diagnostics
            DragDropDiagnostics.SetupTimelineDiagnostics(this);
        }

        private static void OnProjectChangedCallback(
            DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            if (d is TimelineControl control)
            {
                if (e.OldValue is Project oldP)
                {
                    oldP.PropertyChanged -= control.Project_PropertyChanged;
                    oldP.NeedlePositionTimeChanged -= control.Project_NeedlePositionTimeChanged;
                }

                if (e.NewValue is Project newP)
                {
                    newP.PropertyChanged += control.Project_PropertyChanged;
                    newP.NeedlePositionTimeChanged += control.Project_NeedlePositionTimeChanged;

                    if (control.tracksItemsControl != null)
                        control.tracksItemsControl.ItemsSource = newP.Tracks;

                    control.UpdateTimelineFromProject();
                }
            }
        }

        private void Project_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(Project.TimelineZoom) ||
                e.PropertyName == nameof(Project.NeedlePositionTime) ||
                e.PropertyName == nameof(Project.Tracks))
            {
                UpdateTimelineFromProject();
            }
        }

        private void Project_NeedlePositionTimeChanged(object sender, TimeCode e)
        {
            if (!_isUpdatingNeedle)
                UpdateNeedlePosition();
        }

        private void TimelineControl_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Delete)
            {
                DeleteSelectedItems();
                e.Handled = true;
            }
            else if (e.Key == Key.Space)
            {
                if (Project != null)
                {
                    Project.IsPlaying = !Project.IsPlaying;
                    e.Handled = true;
                }
            }
        }

        private void TimeRuler_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Debug.WriteLine("TimeRuler_MouseLeftButtonDown called");
            var pt = e.GetPosition(timeRuler);
            UpdateNeedlePositionFromPixels(pt.X);
            e.Handled = true;
        }

        private void TrackCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Debug.WriteLine("TrackCanvas_MouseLeftButtonDown called");
            _isMouseDown = true;
            _isDragging = true;    // or _isResizingLeft/Right as you decide
            Mouse.Capture(this);     // grab *all* mouse events now
            e.Handled = true;

            if (Project == null)
            {
                Debug.WriteLine("Project is null in TrackCanvas_MouseLeftButtonDown");
                return;
            }

            if (Project.SelectedTool != TimelineSelectedTool.SelectionTool)
                return;

            if (!(sender is Canvas canvas))
            {
                Debug.WriteLine("Sender is not a Canvas in TrackCanvas_MouseLeftButtonDown");
                return;
            }

            if (!(e.OriginalSource is FrameworkElement element))
            {
                Debug.WriteLine("Original source is not a FrameworkElement in TrackCanvas_MouseLeftButtonDown");
                return;
            }

            // See if we can get the track from the DataContext or Tag
            Track track = null;
            if (element.DataContext is Track trackFromDataContext)
            {
                track = trackFromDataContext;
            }
            else if (canvas.Tag is Track trackFromTag)
            {
                track = trackFromTag;
            }
            else if (canvas.DataContext is Track trackFromCanvasDataContext)
            {
                track = trackFromCanvasDataContext;
            }

            // If it's a click on the empty track area
            if (track != null && !IsClickOnTrackItem(e))
            {
                Debug.WriteLine($"Click on empty track area of track: {track.Name}");
                ClearAllSelections();
                // don’t set _isMouseDown or capture the mouse here—
                // this was meant only for real clip drags.
                return;
            }

            // Check if clicking on an actual clip
            ITrackItem trackItem = null;

            // Try to get the track item from the DataContext
            if (element.DataContext is ITrackItem item)
            {
                trackItem = item;
            }
            // If the element is inside a TrackItemControl, find that and get its DataContext
            else
            {
                var trackItemControl = VisualHelper.GetAncestor<TrackItemControl>(element);
                if (trackItemControl != null && trackItemControl.DataContext is ITrackItem itemFromControl)
                {
                    trackItem = itemFromControl;
                    element = trackItemControl;
                }
            }

            if (trackItem != null)
            {
                Debug.WriteLine($"Click on track item: {trackItem.FileName}");

                // Clear any old selection & select this one
                ClearAllSelections();
                _selectedItem = trackItem;
                trackItem.IsSelected = true;

                // Auto-load into preview & play
                if (!string.IsNullOrEmpty(trackItem.FilePath))
                {
                    Project.CurrentMediaPath = trackItem.FilePath;
                    Debug.WriteLine($"Set current media path to: {trackItem.FilePath}");

                    // If there's a MainWindowViewModel in the DataContext, use it to play
                    if (DataContext is MainWindowViewModel vm && vm.PlaybackService != null)
                    {
                        Debug.WriteLine("Loading media and playing");
                        vm.PlaybackService.LoadMedia(trackItem.FilePath);
                        vm.ProjectPlayCommand.Execute(null);
                    }
                }

                // Store state for drag/resize
                _mouseDownPoint = e.GetPosition(canvas);
                _lastMousePosition = _mouseDownPoint;
                _isMouseDown = true;
                _currentTrack = FindParentTrack(trackItem);

                _originalPosition = trackItem.Position;
                _originalStart = trackItem.Start;
                _originalEnd = trackItem.End;

                var container = VisualHelper.GetParent(element) as FrameworkElement;
                if (container?.Parent is Canvas parentCanvas)
                {
                    _originalLeft = Canvas.GetLeft(container);
                    if (double.IsNaN(_originalLeft)) _originalLeft = 0;
                }

                _originalWidth = trackItem.Duration.TotalFrames;

                // Check where the mouse is on the element to determine the operation
                var mouseX = e.GetPosition(element).X;
                var width = (element as FrameworkElement).ActualWidth;

                Debug.WriteLine($"Mouse X: {mouseX}, Width: {width}");
                if (mouseX <= 5)
                {
                    Debug.WriteLine("Setting left resize mode");
                    _isResizingLeft = true;
                    _isResizingRight = false;
                    _isDragging = false;
                }
                else if (mouseX >= width - 5)
                {
                    Debug.WriteLine("Setting right resize mode");
                    _isResizingLeft = false;
                    _isResizingRight = true;
                    _isDragging = false;
                }
                else
                {
                    Debug.WriteLine("Setting drag mode");
                    _isResizingLeft = false;
                    _isResizingRight = false;
                    _isDragging = true;
                }

                e.Handled = true;
            }
        }

        private void TracksScrollViewer_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (Keyboard.Modifiers == ModifierKeys.Control)
            {
                e.Handled = true;
                if (Project == null) return;

                var currentZoom = Project.TimelineZoom;
                var needleTime = Project.NeedlePositionTime;
                var offset = tracksScrollViewer.HorizontalOffset;
                var mouseX = e.GetPosition(tracksScrollViewer).X;
                var viewport = tracksScrollViewer.ViewportWidth;
                var relative = (offset + mouseX) / tracksScrollViewer.ExtentWidth;

                if (e.Delta > 0 && currentZoom < Constants.TimelineZooms.Count)
                    Project.TimelineZoom = Math.Min(currentZoom + 1, Constants.TimelineZooms.Count);
                else if (e.Delta < 0 && currentZoom > 1)
                    Project.TimelineZoom = Math.Max(currentZoom - 1, 1);

                Dispatcher.BeginInvoke(new Action(() =>
                {
                    var newOffset = relative * tracksScrollViewer.ExtentWidth - mouseX;
                    tracksScrollViewer.ScrollToHorizontalOffset(newOffset);
                    BringNeedleIntoView();
                }), System.Windows.Threading.DispatcherPriority.Render);
            }
            else
            {
                tracksScrollViewer.ScrollToHorizontalOffset(
                    tracksScrollViewer.HorizontalOffset - e.Delta);
                e.Handled = true;
            }
        }

        private void TimelineControl_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            if (_selectedItem == null
                || e.LeftButton != MouseButtonState.Pressed
                || !(_isDragging || _isResizingLeft || _isResizingRight))
            {
                return;
            }

            var current = e.GetPosition(tracksScrollViewer);
            var delta = current - _lastMousePosition;
            _lastMousePosition = current;

            double pixelsPerFrame = Constants.GetPixelsPerFrame(Project.TimelineZoom);
            int frameDelta = (int)(delta.X / pixelsPerFrame);
            if (frameDelta == 0) return;

            int newFrame = Math.Max(0, _selectedItem.Position.TotalFrames + frameDelta);
            System.Diagnostics.Debug.WriteLine($"Dragging from {_selectedItem.Position.TotalFrames} → {newFrame}");
            _selectedItem.Position = new TimeCode(newFrame, _selectedItem.Position.FPS);

            e.Handled = true;
        }

        private void TimelineControl_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            Debug.WriteLine("TimelineControl_PreviewMouseLeftButtonUp called");

            if (_selectedItem != null && (_isDragging || _isResizingLeft || _isResizingRight))
            {
                Debug.WriteLine("Registering track item change");
                RegisterTrackItemChange();
            }

            _isDragging = _isResizingLeft = _isResizingRight = _isMouseDown = false;
            _selectedItem = null;
            Mouse.Capture(null);
            e.Handled = true;
        }

        #endregion

        #region Drag and Drop Handlers

        private void Track_DragEnter(object sender, DragEventArgs e)
        {
            Debug.WriteLine("Track_DragEnter called");
            e.Effects = e.Data.GetDataPresent(typeof(ProjectClip))
                ? DragDropEffects.Copy
                : DragDropEffects.None;
            e.Handled = true;
        }

        private void Track_DragOver(object sender, DragEventArgs e)
        {
            // Debug.WriteLine("Track_DragOver called");
            if (e.Data.GetDataPresent(typeof(ProjectClip)) &&
                sender is FrameworkElement fe &&
                fe.DataContext is Track track)
            {
                var clip = e.Data.GetData(typeof(ProjectClip)) as ProjectClip;
                if (clip != null)
                {
                    e.Effects = clip.IsCompatibleWith(track.Type)
                        ? DragDropEffects.Copy
                        : DragDropEffects.None;
                }
                else
                {
                    e.Effects = DragDropEffects.None;
                }
            }
            else
            {
                e.Effects = DragDropEffects.None;
            }
            e.Handled = true;
        }

        private void Track_Drop(object sender, DragEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("Track_Drop called");
            try
            {
                if (e.Data.GetDataPresent(typeof(ProjectClip)) &&
                    sender is FrameworkElement element &&
                    element.DataContext is Track track)
                {
                    var clip = e.Data.GetData(typeof(ProjectClip)) as ProjectClip;
                    if (clip == null)
                    {
                        System.Diagnostics.Debug.WriteLine("Clip is null in Track_Drop");
                        return;
                    }

                    System.Diagnostics.Debug.WriteLine($"Track_Drop: clip={clip.FileName} on track={track.Name}");

                    if (!clip.IsCompatibleWith(track.Type))
                    {
                        System.Diagnostics.Debug.WriteLine("Clip is not compatible with track");
                        return;
                    }

                    var pt = e.GetPosition(element);
                    double pixelsPerFrame = Constants.GetPixelsPerFrame(Project.TimelineZoom);
                    int framePos = (int)(pt.X / pixelsPerFrame);

                    // Ensure clip has a proper length
                    if (clip.Length == null || clip.Length.TotalFrames <= 0)
                    {
                        // Use FFmpeg (via GetClipProperties) to retrieve the actual duration
                        var properties = clip.GetClipProperties();
                        clip.Length = properties.Length;
                        System.Diagnostics.Debug.WriteLine($"Retrieved media duration using FFmpeg: {clip.Length.TotalFrames} frames");
                    }

                    System.Diagnostics.Debug.WriteLine($"Creating track item at frame {framePos} with length {clip.Length.TotalFrames} frames");

                    ITrackItem trackItem;
                    var pos = new TimeCode(framePos, Project.FPS);

                    // Create the appropriate track item type
                    if (FileFormats.SupportedAudioFormats.Contains(System.IO.Path.GetExtension(clip.FilePath).ToLowerInvariant()))
                    {
                        trackItem = new AudioTrackItem(clip, pos, TimeCode.Zero, clip.Length);
                        System.Diagnostics.Debug.WriteLine($"Created AudioTrackItem with duration {trackItem.Duration.TotalFrames} frames");
                    }
                    else
                    {
                        trackItem = new TrackItem(clip, pos, TimeCode.Zero, clip.Length);
                        System.Diagnostics.Debug.WriteLine($"Created TrackItem with duration {trackItem.Duration.TotalFrames} frames");
                    }

                    // Log clip information
                    System.Diagnostics.Debug.WriteLine($"Clip Info - Start: {trackItem.Start.TotalFrames}, End: {trackItem.End.TotalFrames}, Duration: {trackItem.Duration.TotalFrames}");

                    // Add first
                    track.Items.Add(trackItem);
                    RegisterTrackItemAdd(track, trackItem);

                    // Prevent overlap by trimming/removing underlying
                    bool adjustedForOverlap = false;
                    foreach (var existing in track.Items.Where(i => i != trackItem).ToList())
                    {
                        // Check if there's an overlap
                        int existingStart = existing.Position.TotalFrames;
                        int existingEnd = existingStart + existing.Duration.TotalFrames;
                        int newStart = trackItem.Position.TotalFrames;
                        int newEnd = newStart + trackItem.Duration.TotalFrames;

                        if (newStart < existingEnd && newEnd > existingStart)
                        {
                            adjustedForOverlap = true;
                            System.Diagnostics.Debug.WriteLine($"Overlap detected with existing item: {existing.FileName} ({existingStart}-{existingEnd})");

                            // Move the new clip after the existing one
                            trackItem.Position = new TimeCode(existingEnd, trackItem.Position.FPS);
                            System.Diagnostics.Debug.WriteLine($"Moved new clip to position {existingEnd}");
                            break;
                        }
                    }

                    if (!adjustedForOverlap)
                    {
                        System.Diagnostics.Debug.WriteLine("No overlap detected, position unchanged");
                    }

                    System.Diagnostics.Debug.WriteLine($"Added {clip.FileName} @ frame {trackItem.Position.TotalFrames}, duration: {trackItem.Duration.TotalFrames}");
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error in Track_Drop: {ex.Message}");
            }
        }

        private void CreateNewTrack_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(typeof(ProjectClip)) && sender is Border b)
            {
                e.Effects = DragDropEffects.Copy;
                b.Background = new SolidColorBrush(Color.FromRgb(70, 70, 70));
            }
            e.Handled = true;
        }

        private void CreateNewTrack_DragOver(object sender, DragEventArgs e)
        {
            e.Effects = e.Data.GetDataPresent(typeof(ProjectClip))
                ? DragDropEffects.Copy
                : DragDropEffects.None;
            e.Handled = true;
        }

        private void CreateNewTrack_Drop(object sender, DragEventArgs e)
        {
            try
            {
                if (Project != null && e.Data.GetDataPresent(typeof(ProjectClip)))
                {
                    var clip = e.Data.GetData(typeof(ProjectClip)) as ProjectClip;
                    if (clip == null) return;

                    var type = FileFormats.SupportedAudioFormats.Contains(Path.GetExtension(clip.FilePath).ToLowerInvariant())
                        ? TimelineTrackType.Audio
                        : TimelineTrackType.Video;

                    var name = $"{type} Track {Project.Tracks.Count(t => t.Type == type) + 1}";
                    var newTrack = new Track { Name = name, Type = type };
                    Project.Tracks.Add(newTrack);

                    var pt = e.GetPosition(tracksContainer);
                    double zf = Constants.TimelineZooms.TryGetValue(Project.TimelineZoom, out var z) ? z : 1.0;
                    int framePos = (int)(pt.X * zf / Constants.TimelinePixelsInSeparator);

                    ITrackItem trackItem;
                    var pos = new TimeCode(framePos, Project.FPS);
                    if (FileFormats.SupportedAudioFormats.Contains(Path.GetExtension(clip.FilePath).ToLowerInvariant()))
                        trackItem = new AudioTrackItem(clip, pos, TimeCode.Zero, clip.Length);
                    else
                        trackItem = new TrackItem(clip, pos, TimeCode.Zero, clip.Length);

                    newTrack.Items.Add(trackItem);
                    RegisterTrackAdd(newTrack);
                    RegisterTrackItemAdd(newTrack, trackItem);

                    Debug.WriteLine($"Created {name} & added {clip.FileName}");
                    e.Handled = true;
                }

                if (sender is Border border)
                    border.Background = new SolidColorBrush(Color.FromRgb(51, 51, 51));
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error in CreateNewTrack_Drop: {ex.Message}");
            }
        }

        private void RefreshTrackDisplay()
        {
            try
            {
                Application.Current.Dispatcher.InvokeAsync(() =>
                {
                    if (tracksItemsControl.ItemsSource != Project.Tracks)
                    {
                        Debug.WriteLine("Fixing ItemsSource binding");
                        tracksItemsControl.ItemsSource = Project.Tracks;
                    }
                    tracksItemsControl.UpdateLayout();
                    tracksScrollViewer.UpdateLayout();
                });
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Failed to refresh: {ex.Message}");
            }
        }

        #endregion

        #region Drag and Resize Handlers

        private void HandleDragOperation(Vector delta)
        {
            if (_selectedItem == null || _currentTrack == null) return;

            try
            {
                // Obtener la cantidad de píxeles por frame (notar que GetPixelsPerFrame devuelve "píxeles por frame")
                double pixelsPerFrame = Constants.GetPixelsPerFrame(Project.TimelineZoom);

                // Convertir el delta en píxeles a delta en frames (división, no multiplicación)
                int frameDelta = (int)(delta.X / pixelsPerFrame);
                if (frameDelta == 0) return;

                // Calcular la nueva posición en frames y asegurarse de que no sea negativa
                int newFrame = _selectedItem.Position.TotalFrames + frameDelta;
                if (newFrame < 0)
                    newFrame = 0;

                int originalPosition = _selectedItem.Position.TotalFrames;
                System.Diagnostics.Debug.WriteLine($"Dragging from frame {originalPosition} to {newFrame} (delta: {frameDelta})");

                // Actualizar la posición del clip
                _selectedItem.Position = new TimeCode(newFrame, _selectedItem.Position.FPS);

                // Obtener los límites del clip que se está moviendo
                int selectedStart = _selectedItem.Position.TotalFrames;
                int selectedEnd = selectedStart + _selectedItem.Duration.TotalFrames;

                // Verificar colisiones con otros clips en el mismo track
                foreach (var item in _currentTrack.Items)
                {
                    if (item == _selectedItem) continue;

                    int otherStart = item.Position.TotalFrames;
                    int otherEnd = otherStart + item.Duration.TotalFrames;

                    // Si se solapan los rangos
                    if (selectedStart < otherEnd && selectedEnd > otherStart)
                    {
                        System.Diagnostics.Debug.WriteLine($"Overlap detected with {item.FileName} at position {otherStart}");
                        if (originalPosition < otherStart)
                        {
                            int validPos = otherStart - _selectedItem.Duration.TotalFrames;
                            if (validPos < 0)
                                validPos = 0;
                            _selectedItem.Position = new TimeCode(validPos, _selectedItem.Position.FPS);
                            System.Diagnostics.Debug.WriteLine($"Adjusted to position {validPos} (before other clip)");
                        }
                        else
                        {
                            _selectedItem.Position = new TimeCode(otherEnd, _selectedItem.Position.FPS);
                            System.Diagnostics.Debug.WriteLine($"Adjusted to position {otherEnd} (after other clip)");
                        }
                        break;
                    }
                }

                System.Diagnostics.Debug.WriteLine($"Final position: {_selectedItem.Position.TotalFrames}");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error in HandleDragOperation: {ex.Message}");
            }
        }



        private void HandleLeftResize(Vector delta)
        {
            if (_selectedItem == null) return;

            double zf = Constants.TimelineZooms.TryGetValue(Project.TimelineZoom, out var z) ? z : 1.0;
            int frameDelta = (int)(delta.X * zf / Constants.TimelinePixelsInSeparator);
            if (frameDelta == 0) return;

            // Calculate new values
            int newStart = _selectedItem.Start.TotalFrames + frameDelta;
            int newPos = _selectedItem.Position.TotalFrames + frameDelta;

            // Ensure we don't go negative
            if (newPos < 0)
            {
                frameDelta = -_selectedItem.Position.TotalFrames;
                newPos = 0;
                newStart = _selectedItem.Start.TotalFrames + frameDelta;
            }

            // Ensure we don't make the clip too small
            if (newStart >= _selectedItem.End.TotalFrames - 1)
                newStart = _selectedItem.End.TotalFrames - 1;

            // Update the model
            _selectedItem.Start = new TimeCode(newStart, _selectedItem.Start.FPS);
            _selectedItem.Position = new TimeCode(newPos, _selectedItem.Position.FPS);

            Debug.WriteLine($"Left resize: new start={newStart}, new position={newPos}");

            Dispatcher.BeginInvoke(new Action(() =>
            {
            }), System.Windows.Threading.DispatcherPriority.Render);
        }

        private void HandleRightResize(Vector delta)
        {
            if (_selectedItem == null) return;

            double pixelsPerFrame = Constants.GetPixelsPerFrame(Project.TimelineZoom);
            int frameDelta = (int)(delta.X / pixelsPerFrame);
            if (frameDelta == 0) return;

            int newEnd = _selectedItem.End.TotalFrames + frameDelta;
            newEnd = Math.Max(newEnd, _selectedItem.Start.TotalFrames + 1);

            _selectedItem.End = new TimeCode(newEnd, _selectedItem.End.FPS);
        }

        // Fix potential issues with UpdateTrackItemVisual
        private void UpdateTrackItemVisual(ITrackItem item)
        {
            try
            {
                var container = FindTrackItemContainer(item);
                if (container == null)
                {
                    Debug.WriteLine("Could not find container for track item");
                    return;
                }

                // Get accurate zoom factor
                double zf = Constants.TimelineZooms.TryGetValue(Project.TimelineZoom, out var z) ? z : 1.0;

                // Calculate pixel position and width
                double left = item.Position.TotalFrames * Constants.TimelinePixelsInSeparator / zf;
                double width = item.Duration.TotalFrames * Constants.TimelinePixelsInSeparator / zf;

                // Make sure width is positive
                if (width <= 0) width = 10; // Minimum width

                Debug.WriteLine($"Updating track item visual: left={left}, width={width}");

                // Update UI
                Canvas.SetLeft(container, left);
                container.Width = width;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error updating track item visual: {ex.Message}");
            }
        }

        private FrameworkElement FindTrackItemContainer(ITrackItem item)
        {
            if (item == null)
            {
                System.Diagnostics.Debug.WriteLine("Cannot find container for null item");
                return null;
            }

            // Find which track contains this item
            foreach (var track in Project.Tracks)
            {
                if (!track.Items.Contains(item)) continue;

                // First find the track container
                var tc = FindTrackContainer(track);
                if (tc == null)
                {
                    System.Diagnostics.Debug.WriteLine($"Could not find container for track {track.Name}");
                    continue;
                }

                // Then find the canvas inside it
                var canvas = VisualHelper.FindVisualChild<Canvas>(tc);
                if (canvas == null)
                {
                    System.Diagnostics.Debug.WriteLine("Could not find canvas in track container");
                    continue;
                }

                // Look through children to find the one with matching DataContext
                foreach (var child in canvas.Children)
                {
                    if (child is FrameworkElement fe && fe.DataContext == item)
                    {
                        return fe;
                    }
                }

                // If we couldn't find the exact item by direct reference, try matching by ID
                foreach (var child in canvas.Children)
                {
                    if (child is FrameworkElement fe &&
                        fe.DataContext is ITrackItem trackItem &&
                        trackItem.FilePath == item.FilePath &&
                        trackItem.Position.TotalFrames == item.Position.TotalFrames)
                    {
                        System.Diagnostics.Debug.WriteLine("Found item container by matching properties");
                        return fe;
                    }
                }
            }

            System.Diagnostics.Debug.WriteLine($"Could not find container for item {item.FileName}");
            return null;
        }

        private FrameworkElement FindTrackContainer(Track track)
        {
            if (tracksItemsControl == null) return null;

            for (int i = 0; i < tracksItemsControl.Items.Count; i++)
            {
                var container = tracksItemsControl
                    .ItemContainerGenerator
                    .ContainerFromIndex(i) as FrameworkElement;

                if (container?.DataContext == track)
                    return container;
            }
            return null;
        }

        private void WireUpTrackItemEvents()
        {
            Debug.WriteLine("Wiring up track item events");
            foreach (var item in FindVisualChildren<TrackItemControl>(this))
            {
                item.ClipSelected += (s, args) =>
                {
                    Debug.WriteLine($"ClipSelected event fired for {args.TrackItem.FileName}");

                    // clear everything
                    foreach (var tr in Project.Tracks)
                        foreach (var it in tr.Items)
                            it.IsSelected = false;

                    // select only the clicked clip
                    args.TrackItem.IsSelected = true;

                    // Store as the selected item
                    _selectedItem = args.TrackItem;
                };
            }
        }

        private IEnumerable<T> FindVisualChildren<T>(DependencyObject parent) where T : DependencyObject
        {
            int count = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < count; i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                if (child is T t) yield return t;
                foreach (var grand in FindVisualChildren<T>(child))
                    yield return grand;
            }
        }

        #endregion
    }
}