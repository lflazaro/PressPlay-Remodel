﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.IO;
using PressPlay.Helpers;
using PressPlay.Models;
using System.ComponentModel;

namespace PressPlay.Timeline
{
    public partial class TrackItemControl : UserControl
    {
        // Track mouse state for drag operations
        private bool isDragging = false;
        private bool isResizingLeft = false;
        private bool isResizingRight = false;
        private Point dragStartPoint;
        private double originalLeft = 0;
        private double originalWidth = 0;
        private TimeCode _originalEnd; // Store original end time for limiting resize

        // Events for notifying parent of significant actions
        public event EventHandler<TrackItemEventArgs> ClipMoved;
        public event EventHandler<TrackItemEventArgs> ClipResized;
        public event EventHandler<TrackItemEventArgs> ClipSelected;

        public class TrackItemEventArgs : EventArgs
        {
            public ITrackItem TrackItem { get; }

            public TrackItemEventArgs(ITrackItem trackItem)
            {
                TrackItem = trackItem;
            }
        }

        public TrackItemControl()
        {
            InitializeComponent();

            // Set up mouse events for entire control
            this.Loaded += TrackItemControl_Loaded;
            this.MouseLeftButtonDown += TrackItemControl_MouseLeftButtonDown;
            this.MouseMove += TrackItemControl_MouseMove;
            this.MouseLeftButtonUp += TrackItemControl_MouseLeftButtonUp;

            // Set up events for resize handles
            LeftResizeHandle.MouseLeftButtonDown += LeftResizeHandle_MouseLeftButtonDown;
            RightResizeHandle.MouseLeftButtonDown += RightResizeHandle_MouseLeftButtonDown;

            // Set cursor for resize areas
            LeftResizeHandle.Cursor = Cursors.SizeWE;
            RightResizeHandle.Cursor = Cursors.SizeWE;

            DataContextChanged += (s, e) =>
            {
                // When data context changes, update selection visual
                UpdateSelectionVisual();

                // Subscribe to IsSelected changes
                if (e.NewValue is INotifyPropertyChanged notifyObj)
                {
                    notifyObj.PropertyChanged += (sender, args) =>
                    {
                        if (args.PropertyName == "IsSelected")
                        {
                            UpdateSelectionVisual();
                        }
                    };
                }
            };

            System.Diagnostics.Debug.WriteLine("TrackItemControl constructor called");
        }

        private void TrackItemControl_Loaded(object sender, RoutedEventArgs e)
        {
            UpdateVisualState();

            // Make sure data binding is updated
            if (DataContext is ITrackItem trackItem)
            {
                System.Diagnostics.Debug.WriteLine($"TrackItemControl loaded for item: {trackItem.FileName}");

                // We need to subscribe to property changes to update visuals
                // Try to cast to INotifyPropertyChanged (which TrackItem and AudioTrackItem implement)
                if (DataContext is INotifyPropertyChanged notifyObj)
                {
                    notifyObj.PropertyChanged += (s, args) =>
                    {
                        if (args.PropertyName == "IsSelected")
                        {
                            UpdateSelectionVisual();
                        }
                    };
                }

                // Always update the selection visual based on current state
                UpdateSelectionVisual();
            }
        }

        private void UpdateSelectionVisual()
        {
            if (DataContext is ITrackItem trackItem)
            {
                // No need to manually update border - we now use styles and triggers
                // Just log the selection state
                System.Diagnostics.Debug.WriteLine($"Selection state for {trackItem.FileName}: {trackItem.IsSelected}");

                // Force visual refresh
                if (MainBorder != null)
                {
                    // Explicitly refresh style application
                    var style = MainBorder.Style;
                    MainBorder.Style = null;
                    MainBorder.Style = style;

                    // Also refresh the header style
                    var headerBorder = MainBorder.Child as Grid;
                    if (headerBorder != null && headerBorder.Children.Count > 0)
                    {
                        var header = headerBorder.Children[0] as Border;
                        if (header != null)
                        {
                            var headerStyle = header.Style;
                            header.Style = null;
                            header.Style = headerStyle;
                        }
                    }
                }
            }
        }

        private void UpdateVisualState()
        {
            if (this.DataContext is ITrackItem trackItem)
            {
                // Update visual state based on clip type
                if (trackItem is AudioTrackItem)
                {
                    ThumbnailImage.Visibility = Visibility.Collapsed;

                    // Create a waveform visualization instead (simplified here)
                    Border waveformBorder = new Border
                    {
                        Background = new SolidColorBrush(Colors.DarkBlue),
                        Height = 40,
                        VerticalAlignment = VerticalAlignment.Center
                    };

                    // Replace the image with our waveform visualization
                    int imageIndex = MainBorder.Child.GetType().GetProperty("Children").GetValue(MainBorder.Child) is UIElementCollection children ?
                                    children.IndexOf(ThumbnailImage) : -1;

                    if (imageIndex >= 0)
                    {
                        var grid = MainBorder.Child as Grid;
                        grid.Children.RemoveAt(imageIndex);
                        grid.Children.Insert(imageIndex, waveformBorder);
                    }
                }

                // Set handle visibility for fade-in/out points
                FadeInHandle.Visibility = trackItem.FadeInFrame > 0 ? Visibility.Visible : Visibility.Hidden;
                FadeOutHandle.Visibility = trackItem.FadeOutFrame > 0 ? Visibility.Visible : Visibility.Hidden;

                // Position fade handles based on fade settings
                if (trackItem.FadeInFrame > 0)
                {
                    double fadeInPosition = trackItem.FadeInFrame / Constants.TimelineZooms[GetCurrentZoomLevel()];
                    Canvas.SetLeft(FadeInHandle, fadeInPosition - 4); // Offset for handle width
                }

                if (trackItem.FadeOutFrame > 0)
                {
                    double fadeOutPosition = ActualWidth - (trackItem.FadeOutFrame / Constants.TimelineZooms[GetCurrentZoomLevel()]);
                    Canvas.SetLeft(FadeOutHandle, fadeOutPosition - 4);
                }

                // Update selection visual
                UpdateSelectionVisual();
            }
        }

        private int GetCurrentZoomLevel()
        {
            // Try to get the zoom level from the project
            var timelineControl = VisualHelper.GetAncestor<TimelineControl>(this);
            if (timelineControl?.Project != null)
            {
                return timelineControl.Project.TimelineZoom;
            }

            // Default to 1 if not found
            return 1;
        }

        private void TrackItemControl_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("TrackItemControl_MouseLeftButtonDown called");
            try
            {
                // Stop the event from bubbling up to parent containers
                e.Handled = true;

                if (this.DataContext is ITrackItem trackItem)
                {
                    System.Diagnostics.Debug.WriteLine($"Clicked on track item: {trackItem.FileName}");

                    // Set the selected state explicitly
                    trackItem.IsSelected = true;

                    // Raise the clip selected event 
                    ClipSelected?.Invoke(this, new TrackItemEventArgs(trackItem));

                    // Determine if we're near an edge for resizing
                    Point mousePos = e.GetPosition(this);
                    double leftEdge = 5.0;
                    double rightEdge = this.ActualWidth - 5.0;

                    // Reset all state flags first
                    isResizingLeft = false;
                    isResizingRight = false;
                    isDragging = false;

                    if (mousePos.X < leftEdge)
                    {
                        // Left resize mode
                        isResizingLeft = true;
                        System.Diagnostics.Debug.WriteLine("Starting left resize");
                    }
                    else if (mousePos.X > rightEdge)
                    {
                        // Right resize mode
                        isResizingRight = true;

                        // Store the original end time for limiting resize
                        _originalEnd = trackItem.End;

                        System.Diagnostics.Debug.WriteLine("Starting right resize");
                    }
                    else
                    {
                        // Drag mode - this is the key flag that needs to be set correctly
                        isDragging = true;
                        System.Diagnostics.Debug.WriteLine("Starting drag operation");
                    }

                    // Save starting values for the operation
                    // For dragging we need position relative to parent; for resizing relative to this control
                    dragStartPoint = isDragging ?
                                     e.GetPosition(this.Parent as UIElement) :
                                     e.GetPosition(this);

                    // Get current left position (with fallback)
                    originalLeft = Canvas.GetLeft(this);
                    if (double.IsNaN(originalLeft)) originalLeft = 0;

                    originalWidth = this.ActualWidth;

                    // Capture mouse to receive mouse move events even if pointer leaves control
                    this.CaptureMouse();

                    System.Diagnostics.Debug.WriteLine($"Mouse down at position ({mousePos.X}, {mousePos.Y}), isDragging={isDragging}, isResizingLeft={isResizingLeft}, isResizingRight={isResizingRight}");
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error in TrackItemControl_MouseLeftButtonDown: {ex.Message}");
            }
        }

        private void LeftResizeHandle_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (this.DataContext is ITrackItem trackItem)
            {
                // Reset flags and set the correct operation
                isDragging = false;
                isResizingRight = false;
                isResizingLeft = true;

                // Save start values
                dragStartPoint = e.GetPosition(this.Parent as UIElement);
                originalLeft = Canvas.GetLeft(this);
                if (double.IsNaN(originalLeft)) originalLeft = 0;
                originalWidth = this.ActualWidth;

                // Capture mouse and mark as handled
                this.CaptureMouse();
                e.Handled = true;

                System.Diagnostics.Debug.WriteLine("Left resize handle clicked");
            }
        }

        private void RightResizeHandle_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (this.DataContext is ITrackItem trackItem)
            {
                // Reset flags and set the correct operation
                isDragging = false;
                isResizingLeft = false;
                isResizingRight = true;

                // Save start values
                dragStartPoint = e.GetPosition(this.Parent as UIElement);
                originalWidth = this.ActualWidth;
                originalLeft = Canvas.GetLeft(this);
                if (double.IsNaN(originalLeft)) originalLeft = 0;

                // Store original duration in frames - this is what we'll use to limit resize
                // We need to calculate this directly from the model, not from visual properties
                _originalEnd = new TimeCode(trackItem.End.TotalFrames, trackItem.End.FPS);

                System.Diagnostics.Debug.WriteLine($"Original end frame: {_originalEnd.TotalFrames}, Start frame: {trackItem.Start.TotalFrames}");
                System.Diagnostics.Debug.WriteLine($"Original duration (frames): {_originalEnd.TotalFrames - trackItem.Start.TotalFrames}");

                // Capture mouse and mark as handled
                this.CaptureMouse();
                e.Handled = true;

                System.Diagnostics.Debug.WriteLine("Right resize handle clicked");
            }
        }

        private void TrackItemControl_MouseMove(object sender, MouseEventArgs e)
        {
            try
            {
                if (!this.IsMouseCaptured)
                    return;

                if (!isDragging && !isResizingLeft && !isResizingRight)
                    return;

                // Verify mouse button is still pressed
                if (e.LeftButton != MouseButtonState.Pressed)
                {
                    // Button released outside our control
                    FinishDragOrResize();
                    return;
                }

                if (isDragging)
                {
                    // Handle clip dragging
                    Point currentPos = e.GetPosition(this.Parent as UIElement);
                    double deltaX = currentPos.X - dragStartPoint.X;
                    double newLeft = originalLeft + deltaX;

                    // Ensure we don't drag to negative positions
                    if (newLeft < 0) newLeft = 0;

                    // Update position
                    Canvas.SetLeft(this, newLeft);
                    System.Diagnostics.Debug.WriteLine($"Dragging: deltaX={deltaX}, newLeft={newLeft}");

                    // Update the model position
                    UpdateModelPositionDuringDrag(newLeft);
                }
                else if (isResizingLeft)
                {
                    // Handle left-side resize
                    Point currentPos = e.GetPosition(this.Parent as UIElement);
                    double deltaX = currentPos.X - dragStartPoint.X;

                    // Calculate new left and width
                    double newLeft = originalLeft + deltaX;
                    double newWidth = originalWidth - deltaX;

                    // Enforce minimum size
                    if (newWidth < 10)
                    {
                        newWidth = 10;
                        newLeft = originalLeft + originalWidth - 10;
                    }

                    // Ensure we don't resize to negative positions
                    if (newLeft < 0)
                    {
                        newLeft = 0;
                        newWidth = originalWidth + originalLeft;
                    }

                    // Update position and width
                    Canvas.SetLeft(this, newLeft);
                    this.Width = newWidth;

                    // Update model if available
                    if (this.DataContext is ITrackItem trackItem)
                    {
                        var timelineControl = VisualHelper.GetAncestor<TimelineControl>(this);
                        if (timelineControl?.Project != null)
                        {
                            // Calculate new position and source start point
                            double zoomFactor = Constants.TimelineZooms.TryGetValue(timelineControl.Project.TimelineZoom, out var z) ? z : 1.0;
                            int framePosition = (int)(newLeft * zoomFactor / Constants.TimelinePixelsInSeparator);
                            int frameWidth = (int)(newWidth * zoomFactor / Constants.TimelinePixelsInSeparator);

                            // Update position
                            trackItem.Position = new TimeCode(framePosition, timelineControl.Project.FPS);

                            // If the clip is not an unlimited source, adjust the start point
                            if (!trackItem.UnlimitedSourceLength)
                            {
                                // Calculate the difference in frames
                                int frameDelta = (int)(deltaX * zoomFactor / Constants.TimelinePixelsInSeparator);
                                TimeCode oldStart = trackItem.Start;

                                // Adjust the start time (ensure we don't go negative)
                                int newStartFrame = oldStart.TotalFrames + frameDelta;
                                if (newStartFrame < 0) newStartFrame = 0;

                                trackItem.Start = new TimeCode(newStartFrame, oldStart.FPS);
                            }

                            // If end point needs to be maintained, adjust it based on new width
                            int expectedEndFrame = trackItem.Start.TotalFrames + frameWidth;
                            if (trackItem.End.TotalFrames != expectedEndFrame)
                            {
                                trackItem.End = new TimeCode(expectedEndFrame, trackItem.Start.FPS);
                            }

                            System.Diagnostics.Debug.WriteLine($"Updated left resize: Pos={framePosition}, Start={trackItem.Start.TotalFrames}, End={trackItem.End.TotalFrames}");
                        }
                    }
                }
                else if (isResizingRight)
                {
                    // Handle right-side resize
                    Point currentPos = e.GetPosition(this.Parent as UIElement);
                    double deltaX = currentPos.X - (dragStartPoint.X + originalWidth);

                    // Calculate new width with minimum limit
                    double newWidth = originalWidth + deltaX;
                    if (newWidth < 10) newWidth = 10;

                    // Update model if available
                    if (this.DataContext is ITrackItem trackItem)
                    {
                        var timelineControl = VisualHelper.GetAncestor<TimelineControl>(this);
                        if (timelineControl?.Project != null)
                        {
                            // Get zoom factor
                            double zoomFactor = Constants.TimelineZooms.TryGetValue(timelineControl.Project.TimelineZoom, out var z) ? z : 1.0;
                            int frameWidth = (int)(newWidth * zoomFactor / Constants.TimelinePixelsInSeparator);

                            // Check if we need to limit the width for video/audio files
                            bool isLimitedMedia = IsFixedLengthMedia(trackItem);

                            // If it's a video/audio file, check if we're trying to extend beyond original length
                            if (isLimitedMedia && _originalEnd != null)
                            {
                                // Calculate original duration in frames
                                int originalDuration = _originalEnd.TotalFrames - trackItem.Start.TotalFrames;

                                // Limit to original duration - we allow shortening but not extending
                                if (frameWidth > originalDuration)
                                {
                                    // Limit to original duration
                                    frameWidth = originalDuration;

                                    // Update visual width to match the frame limit
                                    newWidth = frameWidth / (zoomFactor / Constants.TimelinePixelsInSeparator);

                                    System.Diagnostics.Debug.WriteLine($"Limited video length to original duration: {originalDuration} frames");
                                }
                            }

                            // Update width visually
                            this.Width = newWidth;

                            // Update the end point in the model
                            trackItem.End = new TimeCode(trackItem.Start.TotalFrames + frameWidth, trackItem.Start.FPS);

                            System.Diagnostics.Debug.WriteLine($"Updated right resize: Start={trackItem.Start.TotalFrames}, End={trackItem.End.TotalFrames}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error in TrackItemControl_MouseMove: {ex.Message}");
            }
        }

        private void TrackItemControl_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
                bool wasDragging = isDragging;
                bool wasResizing = isResizingLeft || isResizingRight;

                if (wasDragging)
                {
                    // Final position update
                    UpdateModelPosition();

                    // Notify of clip moved
                    if (this.DataContext is ITrackItem trackItem)
                    {
                        System.Diagnostics.Debug.WriteLine($"Raising ClipMoved event");
                        ClipMoved?.Invoke(this, new TrackItemEventArgs(trackItem));
                        System.Diagnostics.Debug.WriteLine($"Clip move completed: {trackItem.FileName}");
                    }
                }
                else if (wasResizing)
                {
                    // Notify of resize completion
                    if (this.DataContext is ITrackItem trackItem)
                    {
                        System.Diagnostics.Debug.WriteLine($"Raising ClipResized event");
                        ClipResized?.Invoke(this, new TrackItemEventArgs(trackItem));
                        System.Diagnostics.Debug.WriteLine($"Clip resize completed: {trackItem.FileName}");
                    }
                }

                // Reset state and release mouse capture
                isDragging = false;
                isResizingLeft = false;
                isResizingRight = false;
                _originalEnd = null; // Clear stored end value

                if (this.IsMouseCaptured)
                    this.ReleaseMouseCapture();

                // clear our temporary overrides so binding takes over
                this.ClearValue(Canvas.LeftProperty);
                this.ClearValue(WidthProperty);

                e.Handled = true;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error in TrackItemControl_MouseLeftButtonUp: {ex.Message}");
            }
        }

        private void UpdateModelPositionDuringDrag(double newLeft)
        {
            if (!(this.DataContext is ITrackItem trackItem))
                return;

            var timelineControl = VisualHelper.GetAncestor<TimelineControl>(this);
            if (timelineControl?.Project != null)
            {
                double zoomFactor = Constants.GetZoomFactor(timelineControl.Project.TimelineZoom);
                int framePosition = (int)(newLeft * zoomFactor / Constants.TimelinePixelsInSeparator);

                // Update model position
                trackItem.Position = new TimeCode(framePosition, timelineControl.Project.FPS);
                System.Diagnostics.Debug.WriteLine($"TrackItem Position updated to frame {framePosition}");
            }
        }

        private void UpdateModelPosition()
        {
            if (!(this.DataContext is ITrackItem trackItem))
                return;

            // Get current visual position
            double currentLeft = Canvas.GetLeft(this);
            if (double.IsNaN(currentLeft)) currentLeft = 0;

            // Convert to frame position
            double zoomFactor = Constants.TimelinePixelsInSeparator;

            // Try to get the zoom level from the project
            var timelineControl = VisualHelper.GetAncestor<TimelineControl>(this);
            if (timelineControl?.Project != null)
            {
                zoomFactor *= Constants.GetZoomFactor(timelineControl.Project.TimelineZoom);
                int framePosition = (int)(currentLeft * zoomFactor);

                // Update model position (using TimeCode)
                trackItem.Position = new TimeCode(framePosition, timelineControl.Project.FPS);
                System.Diagnostics.Debug.WriteLine($"Updated position to frame {framePosition}");
            }
        }

        private void FinishDragOrResize()
        {
            System.Diagnostics.Debug.WriteLine("FinishDragOrResize called");

            if (this.IsMouseCaptured)
            {
                System.Diagnostics.Debug.WriteLine("Releasing mouse capture");
                this.ReleaseMouseCapture();
            }

            if (this.DataContext is ITrackItem trackItem)
            {
                if (isDragging)
                {
                    // Ensure the model position is up to date
                    UpdateModelPosition();

                    System.Diagnostics.Debug.WriteLine("Raising ClipMoved event");
                    ClipMoved?.Invoke(this, new TrackItemEventArgs(trackItem));
                    System.Diagnostics.Debug.WriteLine($"Clip move completed: {trackItem.FileName}");
                }
                else if (isResizingLeft || isResizingRight)
                {
                    System.Diagnostics.Debug.WriteLine("Raising ClipResized event");
                    ClipResized?.Invoke(this, new TrackItemEventArgs(trackItem));
                    System.Diagnostics.Debug.WriteLine($"Clip resize completed: {trackItem.FileName}");
                }
            }

            // Reset state flags
            isDragging = false;
            isResizingLeft = false;
            isResizingRight = false;
            _originalEnd = null; // Clear stored end time
        }

        // Helper to check if media has fixed length (video/audio vs image)
        private bool IsFixedLengthMedia(ITrackItem item)
        {
            if (string.IsNullOrEmpty(item?.FilePath))
                return false;

            string ext = Path.GetExtension(item.FilePath).ToLowerInvariant();

            // Video and audio files have fixed length
            return ext == ".mp4" || ext == ".avi" || ext == ".mov" || ext == ".mkv" ||
                   ext == ".wmv" || ext == ".mp3" || ext == ".wav" || ext == ".aac";
        }
    }
}