﻿// TimelineNeedleControl.xaml.cs
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace PressPlay.Timeline
{
    public partial class TimelineNeedleControl : UserControl
    {
        private Rectangle needleRect;
        private Polygon needleHead;

        public static readonly DependencyProperty FillProperty =
            DependencyProperty.Register(
                nameof(Fill),
                typeof(Brush),
                typeof(TimelineNeedleControl),
                new PropertyMetadata(Brushes.Red, OnFillChanged));

        public Brush Fill
        {
            get => (Brush)GetValue(FillProperty);
            set => SetValue(FillProperty, value);
        }

        public TimelineNeedleControl()
        {
            InitializeComponent();

            // Create needle elements after InitializeComponent
            CreateNeedleElements();

            // Set stretching behavior
            this.SizeChanged += TimelineNeedleControl_SizeChanged;
        }

        private void CreateNeedleElements()
        {
            // Find canvas in the template
            Canvas canvas = this.Content as Canvas;
            if (canvas == null)
            {
                canvas = new Canvas();
                this.Content = canvas;
            }

            // Clear any existing children
            canvas.Children.Clear();

            // Create the needle rectangle
            needleRect = new Rectangle
            {
                Width = 1,
                Fill = Fill,
                VerticalAlignment = VerticalAlignment.Stretch,
                HorizontalAlignment = HorizontalAlignment.Left
            };

            // Create the needle head (triangle)
            needleHead = new Polygon
            {
                Fill = Fill,
                Points = new PointCollection { new Point(-5, 0), new Point(6, 0), new Point(0.5, 8) },
                VerticalAlignment = VerticalAlignment.Top,
                HorizontalAlignment = HorizontalAlignment.Left
            };

            // Add the elements to the canvas
            canvas.Children.Add(needleRect);
            canvas.Children.Add(needleHead);

            // Set initial positions
            Canvas.SetLeft(needleRect, 0);
            Canvas.SetTop(needleRect, 0);
            Canvas.SetLeft(needleHead, -2.5);
            Canvas.SetTop(needleHead, 0);
        }

        private void TimelineNeedleControl_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            // Update the needle height
            if (needleRect != null)
                needleRect.Height = this.ActualHeight;
        }

        private static void OnFillChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is TimelineNeedleControl needle)
            {
                // Update the fill color of both parts
                if (needle.needleRect != null)
                    needle.needleRect.Fill = (Brush)e.NewValue;

                if (needle.needleHead != null)
                    needle.needleHead.Fill = (Brush)e.NewValue;
            }
        }
    }
}