﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace PressPlay.Timeline
{
    public partial class ScrubBar : UserControl
    {
        public static readonly DependencyProperty PositionProperty =
            DependencyProperty.Register(nameof(Position), typeof(int), typeof(ScrubBar),
                new FrameworkPropertyMetadata(0, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

        public int Position
        {
            get => (int)GetValue(PositionProperty);
            set => SetValue(PositionProperty, value);
        }

        // In a real app, you might also track "MaxPosition" or "FrameRate" 
        // or pass them in as DependencyProperties:
        public static readonly DependencyProperty MaxPositionProperty =
            DependencyProperty.Register(nameof(MaxPosition), typeof(int), typeof(ScrubBar),
                new FrameworkPropertyMetadata(1000));

        public int MaxPosition
        {
            get => (int)GetValue(MaxPositionProperty);
            set => SetValue(MaxPositionProperty, value);
        }

        private bool _isDragging = false;

        public ScrubBar()
        {
            InitializeComponent();
        }

        private void Canvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            _isDragging = true;
            canvas.CaptureMouse();
            UpdatePosition(e.GetPosition(canvas));
        }

        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (_isDragging)
            {
                UpdatePosition(e.GetPosition(canvas));
            }
        }

        private void Canvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            _isDragging = false;
            canvas.ReleaseMouseCapture();
        }

        private void UpdatePosition(Point mousePos)
        {
            double ratio = mousePos.X / canvas.ActualWidth;
            if (ratio < 0) ratio = 0;
            if (ratio > 1) ratio = 1;

            // Convert to an integer frame or time
            int newPosition = (int)(ratio * MaxPosition);
            Position = newPosition;
        }
    }
}