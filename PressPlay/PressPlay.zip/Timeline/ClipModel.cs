﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace PressPlay.Timeline
{
    public partial class ClipModel : ObservableObject
    {
        [ObservableProperty]
        private string _clipName = "Clip";

        [ObservableProperty]
        private int _startPosition;  // e.g. in frames
        [ObservableProperty]
        private int _endPosition;    // e.g. in frames

        // Additional metadata: isBlank, file path, etc.
    }
}