﻿namespace PressPlay.Models
{
    public enum TimelineTrackType
    {
        Video,
        Audio
        // Add more types as needed.
    }

    public enum TrackItemType
    {
        Video,
        Audio,
        Image
        // Add more types as needed.
    }
}
