﻿using PressPlay.Helpers;
using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media.Imaging;

namespace PressPlay.Converters
{
    /// <summary>
    /// Converts timeline frame numbers to pixel positions based on zoom level
    /// </summary>
    public class FrameToPositionConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if (values == null || values.Length < 2)
                return 0;

            try
            {
                // Extract the frame number and zoom level
                int frameNumber = 0;
                if (values[0] is int intFrames)
                {
                    frameNumber = intFrames;
                }
                else if (values[0] != null && int.TryParse(values[0].ToString(), out int parsedFrames))
                {
                    frameNumber = parsedFrames;
                }

                // Get zoom level
                int zoomLevel = 1;
                if (values[1] is int intZoom)
                {
                    zoomLevel = intZoom;
                }
                else if (values[1] != null && int.TryParse(values[1].ToString(), out int parsedZoom))
                {
                    zoomLevel = parsedZoom;
                }

                // Use the improved Constants helper method to convert frames to pixels
                double pixelPosition = Constants.FramesToPixels(frameNumber, zoomLevel);
                Debug.WriteLine($"Frame {frameNumber} at zoom {zoomLevel} = {pixelPosition}px");

                return pixelPosition;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error in FrameToPositionConverter: {ex.Message}");
                return 0;
            }
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    /// <summary>
    /// Converts timeline frame durations to pixel widths based on zoom level
    /// </summary>
    public class FrameToWidthConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if (values == null || values.Length < 2)
                return 10; // Minimum width

            try
            {
                // Extract the frame count and zoom level
                int frameCount = 0;
                // First check if the values[0] is a TrackItem with Duration property
                if (values[0] is PressPlay.Models.ITrackItem item && item.Duration != null)
                {
                    frameCount = item.Duration.TotalFrames;
                    Debug.WriteLine($"Got duration from TrackItem: {frameCount} frames");
                }
                else if (values[0] is int intFrames)
                {
                    frameCount = intFrames;
                }
                else if (values[0] != null && int.TryParse(values[0].ToString(), out int parsedFrames))
                {
                    frameCount = parsedFrames;
                }

                // Get zoom level
                int zoomLevel = 1;
                if (values[1] is int intZoom)
                {
                    zoomLevel = intZoom;
                }
                else if (values[1] != null && int.TryParse(values[1].ToString(), out int parsedZoom))
                {
                    zoomLevel = parsedZoom;
                }

                // Use the improved Constants helper method
                double pixelWidth = Constants.FramesToPixels(frameCount, zoomLevel);
                Debug.WriteLine($"Duration {frameCount} frames at zoom {zoomLevel} = {pixelWidth}px");

                // Ensure minimum width for visibility
                return Math.Max(10, pixelWidth);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error in FrameToWidthConverter: {ex.Message}");
                return 10; // Minimum width on error
            }
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    /// <summary>
    /// Converter that returns true if a tool is selected
    /// </summary>
    public class TimelineSelectedToolToSelectedConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // value = CurrentProject.SelectedTool
            // parameter = e.g., TimelineSelectedTool.SelectionTool
            if (value == null || parameter == null)
                return false;

            return value.ToString() == parameter.ToString();
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // If IsChecked changed in UI, return the appropriate tool
            if (value is bool isChecked && isChecked && parameter != null)
            {
                return parameter;
            }
            return null;
        }
    }
    public class ByteArrayToImageConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // First, check if the value is a direct string path
            if (value is string imagePath && !string.IsNullOrEmpty(imagePath))
            {
                try
                {
                    // Check if file exists
                    if (File.Exists(imagePath))
                    {
                        BitmapImage image = new BitmapImage();
                        image.BeginInit();
                        image.CacheOption = BitmapCacheOption.OnLoad;
                        image.UriSource = new Uri(imagePath, UriKind.Absolute);
                        image.EndInit();
                        image.Freeze(); // Freeze for UI thread safety
                        return image;
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Error loading image from path: {ex.Message}");
                }
            }

            // If it's not a string path or that failed, try byte array conversion
            if (value is byte[] imageData && imageData.Length > 0)
            {
                try
                {
                    BitmapImage image = new BitmapImage();
                    using (MemoryStream ms = new MemoryStream(imageData))
                    {
                        image.BeginInit();
                        image.CacheOption = BitmapCacheOption.OnLoad;
                        image.StreamSource = ms;
                        image.EndInit();
                        image.Freeze(); // Freeze for UI thread safety
                    }
                    return image;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Error loading image from byte array: {ex.Message}");
                }
            }

            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // Not implemented in a typical scenario
            return null;
        }
    }
}